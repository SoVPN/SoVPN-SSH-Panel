# NetHogs With Json Output

NetHogs V 0.8.7




````
bash <(curl -Ls https://raw.githubusercontent.com/mahmoud-ap/nethogs-json/master/install.sh --ipv4)
````

