-- MariaDB dump 10.19  Distrib 10.6.16-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: localhost    Database: SoVPNSSH
-- ------------------------------------------------------
-- Server version	10.6.16-MariaDB-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cp_admins`
--

DROP TABLE IF EXISTS `cp_admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cp_admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `role` varchar(50) NOT NULL,
  `credit` float NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `ctime` int(11) NOT NULL,
  `utime` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cp_admins`
--

LOCK TABLES `cp_admins` WRITE;
/*!40000 ALTER TABLE `cp_admins` DISABLE KEYS */;
INSERT INTO `cp_admins` VALUES (1,'fdp','$2y$10$wgYxRMJc7YFoOwcR.xcXd.pCsWapUS6UgbsFVzYzXuIPH0ckdmh0K','افشین','admin',0,1,1691287888,1699089615),(5,'robot','$2y$10$ruWKgO5roc/gKqOsm65ugurfr60GSkDVg/mFjCWqEI3Hn8WTjqeVO','ربات','admin',0,1,1699089598,1702763203),(6,'behi','$2y$10$JJwZQDt3uqXk4ugYCwS6kuGKVdgDuPXPTYmyL7abE31EmqGWq18CW','بهنام','employee',0,1,1709559147,1709922469);
/*!40000 ALTER TABLE `cp_admins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cp_public_apis`
--

DROP TABLE IF EXISTS `cp_public_apis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cp_public_apis` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(110) NOT NULL,
  `api_key` varchar(100) NOT NULL,
  `ctime` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `api_key` (`api_key`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cp_public_apis`
--

LOCK TABLES `cp_public_apis` WRITE;
/*!40000 ALTER TABLE `cp_public_apis` DISABLE KEYS */;
/*!40000 ALTER TABLE `cp_public_apis` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cp_settings`
--

DROP TABLE IF EXISTS `cp_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cp_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(512) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cp_settings`
--

LOCK TABLES `cp_settings` WRITE;
/*!40000 ALTER TABLE `cp_settings` DISABLE KEYS */;
INSERT INTO `cp_settings` VALUES (1,'ssh_port','2053'),(2,'udp_port','7301'),(3,'multiuser','1'),(4,'app_version',''),(5,'connected_text',''),(6,'domain_url','http://sshpanel.sovpn.sbs:2088'),(7,'fake_url','https://google.com'),(9,'calc_traffic','1'),(10,'app_last_version','1.2'),(11,'users_panel','{\"support_url\":\"https:\\/\\/t.me\\/SoVPN_bot\",\"theme\":\"dark\",\"logo_url\":\"\",\"welecom_text\":\"\"}');
/*!40000 ALTER TABLE `cp_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cp_traffics`
--

DROP TABLE IF EXISTS `cp_traffics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cp_traffics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `download` float NOT NULL,
  `upload` float NOT NULL,
  `total` float NOT NULL,
  `ctime` int(11) NOT NULL,
  `utime` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=155 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cp_traffics`
--

LOCK TABLES `cp_traffics` WRITE;
/*!40000 ALTER TABLE `cp_traffics` DISABLE KEYS */;
INSERT INTO `cp_traffics` VALUES (16,'mehdiahani',3730,6286,10016,1692991430,1710286176),(25,'mehdimasoud',8106,10973,19079,1692991743,1710304756),(30,'ilarreza',1678,4841,6519,1692991917,1710283610),(32,'narjes',1421,2636,4057,1692991979,1710253483),(36,'nasimmaryams',4460,12952,17412,1692992096,1710275348),(37,'ilarasma',1304,6193,7497,1692992124,1710275053),(38,'saharhaghighi02',717,3167,3884,1692992167,1710304756),(43,'raminn',3060,6926,9986,1692992363,1710288056),(48,'mehdielahe',7954,33099,41053,1692992544,1710304721),(55,'saharhaghighi',13842,10799,24641,1692992766,1710285135),(56,'ilar',4966,18057,23023,1692992783,1710285520),(57,'saeed',573,3468,4041,1692992815,1710278804),(58,'maryam',7444,37729,45173,1692992830,1710278944),(60,'dorinsepideh',4843,11130,15973,1692992885,1710287541),(61,'sahartahereh',380,3397,3777,1692992906,1710284330),(62,'ilarsara',5693,9545,15238,1692992926,1710288306),(63,'ilarhedi',2907,13822,16729,1692992958,1710281384),(64,'saharabolfazl',34006,66607,100613,1692992980,1710304366),(65,'shamim',264,1666,1930,1692993005,1710287646),(66,'faramarzmehrshad',14759,26835,41594,1692993047,1710304746),(67,'nasim',3122,8161,11283,1692993074,1710303706),(68,'mehdimani',1390,3972,5362,1692993101,1710287736),(69,'sahar',13968,10773,24741,1692993116,1710289762),(71,'saharparisa',4014,18529,22543,1692993179,1710304696),(73,'shahrzad',3376,13562,16938,1692993233,1710304701),(79,'ilarshayan',2842,7500,10342,1693674679,1710289617),(80,'sovpn',86570,239449,326019,1693772276,1710304736),(83,'mehdihoseinemadi',365,1074,1439,1694703825,1710246241),(89,'paria',1176,1568,2744,1696666296,1710194671),(97,'saharcom',0,0,0,1698506412,1707994812),(104,'somimaryam',4588,21087,25675,1699133337,1710297089),(106,'sarinaanoosheh',8236,19517,27753,1699527291,1710304726),(112,'ilarmehrnaz',128,103,231,1701896674,1709649098),(113,'mehdiesmaeil',581,1671,2252,1702226942,1710281705),(116,'somi',2734,9457,12191,1702766541,1710288781),(118,'ilarsabet',3262,6854,10116,1702819439,1710291572),(119,'mehdipoorya',11667,16109,27776,1703259816,1708211411),(124,'moji',801,513,1314,1703282939,1710281414),(134,'dorinsarina',0,0,0,1704483604,1709586679),(144,'saharamir',10680,7276,17956,1706733892,1710304721),(145,'mehdi',4022,9200,13222,1707234816,1710287591),(147,'beni',4148,12981,17129,1708624803,1710287086),(149,'mehdiertom',1029,7147,8176,1709485705,1710304756),(151,'mehdiertom2',3618,4658,8276,1709744213,1710287001),(153,'nooshin',2336,4412,6748,1709920914,1710304756),(154,'afshin',7,27,34,1710182223,1710251577);
/*!40000 ALTER TABLE `cp_traffics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cp_users`
--

DROP TABLE IF EXISTS `cp_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cp_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `admin_uname` varchar(255) NOT NULL,
  `token` varchar(20) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mobile` varchar(50) NOT NULL,
  `mobilebrand` varchar(15) NOT NULL,
  `operator` varchar(20) NOT NULL,
  `useruuid` varchar(36) NOT NULL,
  `usersubs` text NOT NULL,
  `usersinfo` text NOT NULL,
  `desc` text NOT NULL,
  `limit_users` int(11) NOT NULL,
  `start_date` int(11) NOT NULL,
  `end_date` int(11) NOT NULL,
  `expiry_days` int(11) NOT NULL,
  `status` varchar(50) NOT NULL,
  `traffic` float NOT NULL,
  `ctime` int(11) NOT NULL,
  `utime` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `admin_uname` (`admin_uname`)
) ENGINE=InnoDB AUTO_INCREMENT=155 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cp_users`
--

LOCK TABLES `cp_users` WRITE;
/*!40000 ALTER TABLE `cp_users` DISABLE KEYS */;
INSERT INTO `cp_users` VALUES (16,'mehdiahani','fdp','f97ab5','mehdiahani2023','','','Android','Irancell','8bc822c4-5dcf-42a3-b89f-37d3ac138979','mehdiahanidts37aih2jzg1zcj','','',1,1709067886,1711659886,30,'active',102400,1692991430,1707187804),(25,'mehdimasoud','fdp','e51541','mehdimasoud2023','','','Android','Irancell','','','','',1,1707912454,1710590854,31,'active',102400,1692991743,1695039765),(30,'ilarreza','fdp','ab880a','ilarreza2023','','','Android','Irancell','dc062513-1f95-427e-9298-671db944b69c','ilarrezaqgbo28fdoxs822fg','','',1,1709284701,1711963101,31,'active',102400,1692991917,1707187787),(32,'narjes','fdp','5a769d','narjes2023','','','iPhone','Irancell','48ddee9e-4475-47e1-b54a-5642bc5f749e','narjespqq8xejl6s2rkrr6','','',1,1709155535,1711747535,30,'active',102400,1692991979,1707187776),(36,'nasimmaryams','fdp','06c9c2','nasimmaryams2023','','','iPhone','HamrahAval','09033e6e-b544-4adc-93e1-2db9144fcf9a','nasimmaryamsid1fku813dt1eppj','','',1,1707705211,1710275400,29,'expiry_date',102400,1692992096,1707705228),(37,'ilarasma','fdp','8ea3f9','ilarasma2023','','','iPhone','HamrahAval','45539265-3705-4c5a-be47-ae6db68c92eb','ilarasmak4dp9vuntq5mcm17','','',1,1709587275,1712781000,35,'active',102400,1692992124,1709748767),(38,'saharhaghighi02','fdp','7cc1a8','saharhaghighi022023','','','Android','HamrahAval','','','','',1,1709532283,1712124283,30,'active',102400,1692992167,1693374069),(43,'raminn','fdp','865026','raminn2023','','','','','a40d4e61-92f4-42de-b91d-09a1777dab14','raminnhdtqhn292tlicjqj','','',1,1709155461,1711747461,30,'active',102400,1692992363,1707187725),(48,'mehdielahe','fdp','79869a','mehdielahe2023','','','Android','HamrahAval','37f82fe4-c19e-424f-bfbe-66cfe0264a80','mehdielahenj5qhkkexdvn6x6a','','',1,1707926631,1710518631,30,'active',102400,1692992544,1707235824),(55,'saharhaghighi','fdp','053a46','saharhaghighi2023','','','iPhone','HamrahAval','','','','',1,1709532264,1712124264,30,'active',102400,1692992766,1693374040),(56,'ilar','fdp','919d50','ilar2023','','','iPhone','HamrahAval','fa1b34ed-74cc-4661-9f0a-07ddd9a318d6','ilar8cq8q49cdrf1a3nj','','',1,1707361478,1712594650,31,'active',102400,1692992783,1707361487),(57,'saeed','fdp','34ac78','saeed2023','','','iPhone','HamrahAval','902055d2-1e45-4f53-93d4-15ddc356f110','saeedygmj14l3g43tr2l8','','',1,1708896884,1711488884,30,'active',102400,1692992815,1707187688),(58,'maryam','fdp','b86c0c','maryam2023','','','iPhone','HamrahAval','8ff4b98c-13ba-486f-b342-baef44566fb9','maryamwidv897h7vps6ci6','','',1,1706303958,1711398600,28,'active',102400,1692992830,1708896862),(60,'dorinsepideh','fdp','9bb6c3','dorinsepideh2023','','','iPhone','HamrahAval','7b7f58f8-2fb7-41a4-a4a3-355972ee4af7','dorinsepidehos0ff8koj8rv0suf','','',1,1707947736,1710539736,30,'active',102400,1692992885,1707187673),(61,'sahartahereh','fdp','fa1428','z629r3t','','','Android','Irancell','cb0f2dde-060e-46a7-84fe-53b6336c983c','sahartaherehe8rjuto0eurekvqe','','',1,1709155180,1711833580,31,'active',102400,1692992906,1708693500),(62,'ilarsara','fdp','515d3e','ilarsara2023','','','iPhone','Irancell','0fe97ddb-136a-44d9-94b3-4843c095cdf8','ilarsaravuqypvnagdr3imso','','',1,1707771275,1710363275,30,'active',102400,1692992926,1707187649),(63,'ilarhedi','fdp','ea2330','ilarhedi2023','','','iPhone','HamrahAval','c66bec03-8f34-48d1-a052-cfd9c9536966','ilarhedi0yqp8zhdpmz0hmyb','','',1,1705869405,1710966600,27,'active',102400,1692992958,1708554022),(64,'saharabolfazl','fdp','557ae3','saharabolfazl202320','','','','','2f04aa59-54a2-41c1-86b5-9655f2253eba','saharabolfazlaw8hlx3mipsk95bi','','',1,1705783419,1711053000,28,'active',102400,1692992980,1708553701),(65,'shamim','fdp','be1a88','shamim2023','','','iPhone','HamrahAval','bd1c64db-aad9-43fd-981d-d60b08fcee8e','shamimozjd6tl703qlmmns','','',2,1710046133,1712638133,30,'active',307200,1692993005,1707187564),(66,'faramarzmehrshad','fdp','a397b2','faramarzmehrshad2023','','','iPhone','Irancell','342f12f6-6c2d-44e0-a8dd-15f830ebded5','faramarzmehrshadqg2hn4a58cpe9vt5','','',2,1707947715,1710539715,30,'active',153600,1692993047,1707187551),(67,'nasim','fdp','3ddf8d','nasim2023','','','iPhone','HamrahAval','2f38f1fc-bed4-4d9a-bb3f-b2291dbecab4','nasim1o3au7px5nhj70uq','','',1,1709155051,1711747051,30,'active',102400,1692993074,1707187466),(68,'mehdimani','fdp','60cfe4','7iiz8gd','','','iPhone','HamrahAval','c781f613-b369-4b63-8a8d-c8a28de16d67','mehdimani-u31kc6accvkwbu5m','','',2,1709212021,1711804020,30,'active',102400,1692993101,1707235778),(69,'sahar','fdp','57a528','sahar2023','','','iPhone','HamrahAval','','','','',1,1708101134,1710779534,31,'active',102400,1692993116,1703736447),(71,'saharparisa','fdp','64b0ea','saharparisa2023','','','iPhone','HamrahAval','43e60fd1-6e4a-4aaa-9ae9-07e54d686695','saharparisaesho6zo7sxzyyaf5','','',1,1705765453,1710966600,27,'active',102400,1692993179,1708553945),(73,'shahrzad','fdp','7949ab','shahrzad2023','','','Android','HamrahAval','','','','',1,1708101123,1710779523,31,'active',102400,1692993233,1695031891),(79,'ilarshayan','fdp','82738b','ilarshayan202320','','','Android','Irancell','115a66f3-a15e-4a5f-a574-7f45a676ee14','ilarshayansn57ha30unreiv3r','','',1,1709587346,1712179345,30,'active',102400,1693674679,1707187243),(80,'sovpn','fdp','362582','sovpn202320','','','','','','','','',50,1706265239,1759055638,611,'active',512000,1693772276,0),(83,'mehdihoseinemadi','fdp','a84d78','mehdihoseinemadi2023','','','iPhone','HamrahAval','57d7d3a2-e022-4f57-ba2c-f558222f6273','mehdihoseinemadicoxl1izgc90mbral','','',1,1710054592,1712646592,30,'active',102400,1694703825,1707235694),(89,'paria','fdp','6ab92f','paria2023','','','iPhone','Irancell','0d4a1d3e-3549-47bb-8039-fed32fdca39b','pariaxmu4ld6m93ghzlm1','','',1,1709587017,1712179017,30,'active',102400,1696666296,1707187202),(97,'saharcom','fdp','a434f9','saharcom202320','','','','','','','Computer','',1,1707994812,1710586812,30,'active',102400,1698506412,1701451425),(104,'somimaryam','fdp','f3e266','somimaryam2023','','','iPhone','HamrahAval','5fc753a5-5442-4ab2-9817-cfa9fa965955','somimaryam6unh67y03szrx7mu','','',2,1709586915,1712178915,30,'active',204800,1699133337,1707187038),(106,'sarinaanoosheh','fdp','610faf','sarinaanoosheh2023','','','Android','HamrahAval','bd1c8935-92d9-4afc-9a92-531b8ff13179','sarinaanoosheh1m98byy4o2l17so1','','',1,1707361444,1712594624,31,'active',102400,1699527291,1707361460),(112,'ilarmehrnaz','fdp','e7fba7','ilarmehrnaz2023','','','iPhone','HamrahAval','47763f08-ad8c-4e2b-89b3-b11edcfbf1df','ilarmehrnazx7p7fdl4ydnkuf7x','','',1,1709588367,1712180367,30,'de_active',102400,1701896674,1707187053),(113,'mehdiesmaeil','fdp','33c17c','mehdiesmaeil2023','','','Android','Irancell','','','','',1,1709981686,1712573686,30,'active',102400,1702226942,1707304440),(116,'somi','robot','faee89','Iraj1590','','','iPhone','HamrahAval','','','','',10,1702766541,1734294600,314,'active',10240000,1702766541,1707151965),(118,'ilarsabet','fdp','62ce78','ilarsabet2023','','','Android','Irancell','','','','',1,1707994802,1710586802,30,'active',102400,1702819439,1703727749),(119,'mehdipoorya','fdp','b98cb2','mehdipoorya2023','','','Android','HamrahAval','','','','',1,1705768988,1708447388,31,'expiry_date',102400,1703259816,1703727739),(124,'moji','fdp','1d4a23','h3gsoh1','','','iPhone','HamrahAval','','','','',1,1703282939,1735936200,372,'active',102400,1703282939,1703727677),(134,'dorinsarina','fdp','0e7d6f','7nni82o','','','iPhone','HamrahAval','f18d287b-ea02-4dc0-b8b8-0f35100fb5f8','dorinsarina2fjynincuxh5ie37','','',1,1709586679,1712178679,30,'de_active',102400,1704483604,1707187102),(144,'saharamir','fdp','23ecfc','w4epgl9','','','iPhone','HamrahAval','342d2ffa-c1da-4027-be57-22cb159e3aa7','saharamirvd8g6ku73fu1mgj9','','',1,1709155366,1711833766,31,'active',102400,1706733892,1707187191),(145,'mehdi','fdp','86ce22','xm9bdlk','','','iPhone','Irancell','da66e03f-3a08-4252-946b-bf77e618247f','mehdi-x9n05rcb7srqnk7e','','',2,1707234816,1738182599,358,'active',204800,1707234816,0),(147,'beni','fdp','b19a9e','n7gpji7','','','Android','Irancell','','','','',2,1708624803,1718829000,115,'active',102400,1708624803,1708826065),(149,'mehdiertom','fdp','633b73','kytpngt','','','Android','Irancell','77a61f36-5ee8-4d77-85db-7c12fbcdd4f0','ys44u9525m8th509','','',1,1709485705,1711917000,28,'active',102400,1709485705,1709485824),(151,'mehdiertom2','fdp','baa4ae','4a5zgxl','','','Android','HamrahAval','','','','',1,1709744213,1712262599,29,'active',102400,1709744213,0),(153,'nooshin','fdp','141154','wp3sk9p','','','iPhone','HamrahAval','3cfbc259-887b-438e-8a73-3097761ef9a4','aw3up4vilh8q7l1s','','',2,1709920914,1745008200,406,'active',102400,1709920914,1709921113),(154,'afshin','fdp','693374','SaOf1590','','','iPhone','HamrahAval','','','','',2,1710182223,1738182599,324,'active',10240000,1710182223,0);
/*!40000 ALTER TABLE `cp_users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-03-13  8:09:19
