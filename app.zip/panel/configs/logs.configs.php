<?php 
/**
 * By SoVPN
 * Github: https://github.com/SoVPN
 */

if (!defined('PATH')) die();


$configs['logger']['enabled'] = true;
$configs['logger']['name'] = '';
$configs['logger']['addr'] = '';
?>
