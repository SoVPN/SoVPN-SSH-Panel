<?php
$userValues         = isset($userValues) ? $userValues : null;
$userId             = getArrayValue($userValues, "id");
$username           = getArrayValue($userValues, "username");
$password           = getArrayValue($userValues, "password");
$email              = getArrayValue($userValues, "email");
$mobile             = getArrayValue($userValues, "mobile");
$mobilebrand        = getArrayValue($userValues, "mobilebrand");
$operator           = getArrayValue($userValues, "operator");
$useruuid           = getArrayValue($userValues, "useruuid");
$usersubs           = getArrayValue($userValues, "usersubs");
$usersinfo          = getArrayValue($userValues, "usersinfo");
$traffic            = getArrayValue($userValues, "format_traffic");
$startDate          = getArrayValue($userValues, "start_date");
$endDate            = getArrayValue($userValues, "end_date");
$expiryDays         = getArrayValue($userValues, "expiry_days");
$expiryType         = getArrayValue($userValues, "expiry_type");
$concurrentUsers    = getArrayValue($userValues, "limit_users");
$consumerTraffic    = getArrayValue($userValues, "format_consumer_traffic");
$endDateJD          = getArrayValue($userValues, "end_date_jd"); //jalali date
$startJD            = getArrayValue($userValues, "start_date_jd"); //jalali date
$remainingDays      = getArrayValue($userValues, "remaining_days", 0);
$netmodQrUrl        = getArrayValue($userValues, "netmod_qr_url", "");
$status             = getArrayValue($userValues, "status", "");
$adminName          = getArrayValue($userValues, "admin_name", "");
$desc               = getArrayValue($userValues, "desc", "");
$arrayConfig        = getArrayValue($userValues, "array_config", []);
$diffrenceDate      = getArrayValue($userValues, "diffrence_date", "");
$publicLink         = getArrayValue($userValues, "public_link", "");


$remainingText = "";
if ($remainingDays >= 0) {
    $remainingText = "$remainingDays روز دیگر";
} else if ($remainingDays < 0) {
    $remainingText = "<span class='text-danger'>" . abs($remainingDays) . " روز گذشته</span>";
}

$editViewUrl = "users/$userId/edit?ref=details";

$values = [
    [
        "label" => "نام کاربری",
		"value" => "<span class='cursor-pointer' data-copy='true' data-text='$username' data-bs-toggle='tooltip' title='کپی'>$username</span>",
    ],
    [
        "label" => "رمز عبور",
        "value" => "<span class='cursor-pointer' data-copy='true' data-text='$password' data-bs-toggle='tooltip' title='کپی'>$password</span>",
    ],
    [
        "label" => "ترافیک مصرفی",
        "value" => $consumerTraffic ? "<span id='spn-user-traffic'>$consumerTraffic</span>" : 0
    ],
    [
        "label" => "تاریخ پایان",
        "value" => $endDateJD,
    ],
    [
        "label" =>  "زمان باقی مانده",
        "value" => $remainingText,
    ],
    [
        "label" =>  "تعداد کاربران",
        "value" => $concurrentUsers,
    ],
	[
        "label" => "مدل گوشی",
        "value" => $mobilebrand,
    ],
	[
        "label" => "سیمکارت",
        "value" => $operator,
    ],
	[
        "label" => "کد UUID",
        "value" => $useruuid,
    ],
	[
        "label" => "کد Subscribtion",
        "value" => $usersubs,
    ],
    [
        "label" => "لینک کاربر",
        "value" => "<a target='_blank' class='user-link' href='$publicLink'>$publicLink</a>",
    ],
    [
        "label" => "توضیحات",
        "value" => $desc,
    ],
];

?>

<div class="modal-dialog modal-lg modal-dialog-scrollable">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title">اطلاعات کاربر</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body ">
            <div class="row">
                <div class="col-lg-8 border-end">
              <?php foreach ($values as  $item) {
                        $label = $item["label"];
                        $value = $item["value"]; ?>
                    <div class="d-flex flex-row align-items-center justify-content-between border-bottom py-2">
						<span class="text-muted details-right"><?= $label ?></span>
						<span class=" fw-bold details-left"><?= $value ? $value : "-" ?></span>
					</div>
			<?php	}	?>
				</div>
                <div class="col-lg-4">
                    <div class="p-1 h-100">
                        <div class="row justify-content-between align-items-center h-100">
                            <div class="col-6 col-sm-6 px-1 col-md-12">
                                <div class="actions btn-actions-mobile">	
									<button class="btn w-100 btn-normal-margin btn-Square-normal mb-2 btn-ajax-views" data-url="<?= $editViewUrl ?>">
										ویرایش
									</button>
									<button class="btn-chng-active btn-Square-normal btn-normal-margin btn mb-2 btn-<?= $status == "active" ? "warning" : "success" ?> w-100 mb-2" data-active="<?= $status == "active" ? 1 : 0 ?>" data-id="<?= $userId ?>">
										<?= $status == "active" ? "غیر فعال کردن" : "فعال کردن" ?>
									</button>
								 <?php if ($userRole == "admin") { ?>
										<button class="btn-reset-traffic btn-normal-margin btn-delete btn btn-Square-normal w-100 mb-2" data-id="<?= $userId ?>">
											ریست ترافیک
										</button>
								 <?php } ?>
									<button class="btn-copy-config btn btn-normal-margin btn-Square-normal w-100 mb-2 btn-copy-config" data-config='<?= json_encode($arrayConfig) ?>'>
										کپی کانفیگ
									</button>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>