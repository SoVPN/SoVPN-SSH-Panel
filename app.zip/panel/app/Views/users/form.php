<?php
$userValues         = isset($userValues) ? $userValues : null;
$userId             = getArrayValue($userValues, "id");
$username           = getArrayValue($userValues, "username");
$password           = getArrayValue($userValues, "password");
$email              = getArrayValue($userValues, "email");
$mobile             = getArrayValue($userValues, "mobile");
$mobilebrand        = getArrayValue($userValues, "mobilebrand", "");
$operator           = getArrayValue($userValues, "operator", "");
$useruuid           = getArrayValue($userValues, "useruuid");
$usersubs           = getArrayValue($userValues, "usersubs");
$usersinfo          = getArrayValue($userValues, "usersinfo");
$desc               = getArrayValue($userValues, "desc");
$traffic            = getArrayValue($userValues, "traffic");
$startDate          = getArrayValue($userValues, "start_date");
$endDate            = getArrayValue($userValues, "end_date");
$expiryDays         = getArrayValue($userValues, "expiry_days");
$expiryType         = getArrayValue($userValues, "expiry_type");
$concurrentUsers    = getArrayValue($userValues, "limit_users");
$endDateJD          = getArrayValue($userValues, "end_date_jd"); //jalali date
$startDateJD        = getArrayValue($userValues, "start_date_jd"); //jalali date


$formMethod = $userId ? "put" : "post";
$formAction = $userId ? baseUrl("ajax/dashboard/$userId") : baseUrl("ajax/dashboard");
$expiryType = !$userId ? "date" : (!$startDate ? "days" : "date");

$detailsUrl = "dashboard/$userId/info";
if ($traffic) {
    $traffic  = trafficToGB($traffic);
}

?>

<div class="modal-dialog modal-lg modal-dialog-scrollable">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title">
                <?php if (!empty($refrence)) { ?>
                    <?php if ($refrence == "details") { ?>
                        <button type="button" class="btn btn-secondary rounded-circle btn-icon btn-ajax-views" data-url="<?= $detailsUrl ?>">
							<i class="fa fa-arrow-right"></i>
                        </button>
                    <?php } ?>
                <?php } ?>
                <?= $userId  ? "ویرایش کاربر" : "افزودن کاربر" ?>
            </h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            <form id="user-form" method="<?= $formMethod ?>" action="<?= $formAction ?>">
                <div class="row-user">
                    <div class="col-md-6">
                        <div class="form-group mb-2">
                            <label for="username" class="form-label">نام کاربری (فقط حروف انگلیسی و اعداد)</label>
                            <input type="text" <?= $userId ? "disabled" : "" ?> value="<?= $username ?>" name="username" class="form-control" placeholder="نام کاربری را وارد کنید" required>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group mb-2">
                            <label for="password" class="form-label">رمز عبور</label>
                            <div class="input-group">
                                <input type="text" value="<?= $password ?>" name="password" class="form-control" placeholder="رمز عبور را وارد کنید" required>
                                <button class="btn btn-Square btn-Square-left btn-outline-primary" type="button" id="btn-generate-pass">
									<i class="fa fa-key"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row-user row-phone">
                    <div class="col-md-6">
                        <div class="form-group">
							<div class="mb-9">
								<div class="mb-10">
									<label for="mobilebrand" class="form-label form-phone-label">مدل گوشی</label>
								</div>
								<div class="mb-10">
									<input id="mob-iph" class="mobile-iphone form-check-input" type="radio" name="mobilebrand" value="iPhone" <?= $mobilebrand == "iPhone" ? "checked" : "" ?>>
									<label for="mob-iph" class="btn btn-Square btn-Square-normal mobilebrand-iphone form-check-label  mb-0 form-phone"><i class='fab fa-apple menu-icon iPhone-phone-img mb-2 icon' width="30"></i></label>
								</div>
								<div class="mb-10">
									<input id="mob-and" class="mobile-android form-check-input" type="radio" name="mobilebrand" value="Android" <?= $mobilebrand == "Android" ? "checked" : "" ?>>
									<label for="mob-and" class="btn btn-Square btn-Square-normal mobilebrand-android form-check-label mb-0 form-phone"><i class="fab fa-android menu-icon Android-phone-img phone-img-info mb-2 icon"  width="30"></i></label>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<div class="mb-9">
								<div class="mb-10">
									<label for="mobilebrand" class="form-label form-sim-label">سیمکارت</label>
								</div>
								<div class="mb-10">
									<input id="op-ham" class="sim-hamrahaval form-check-input" type="radio" name="operator" value="HamrahAval" <?= $operator == "HamrahAval" ? "checked" : "" ?>>
									<label for="op-ham" class="btn  btn-Square btn-Square-normal operator-hamr form-check-label mb-0 form-sim"><img src="<?= assets("images/mci.svg") ?>" width="30" class="HamrahAval-sim-img sim-img-info mb-2" /></label>
								</div>
								<div class="mb-10">
									<input id="op-ira" class="sim-irancell form-check-input" type="radio" name="operator" value="Irancell" <?= $operator == "Irancell" ? "checked" : "" ?>>
									<label for="op-ira" class="btn btn-Square btn-Square-normal operator-iran form-check-label mb-0 form-sim"><img src="<?= assets("images/mtn.svg") ?>" width="30" class="Irancell-sim-img sim-img-info mb-2" /></label>
								</div>
							</div>
						</div>
                    </div>
                </div>
				<div class="row-user">
					<div class="col-md-6">
                        <div class="form-group mb-2">
                            <label for="useruuid" class="form-label form-label-span">
								<span class="label-span" dir="rtl">: UUID کد</span>
							</label>
							<div class="input-group">
								<span class="btn-clearField" onclick="document.getElementById('input-user-uuid').value = ''"></span> 
								<input id="input-user-uuid" type="text" name="useruuid" value="<?= $useruuid ?>" class="form-control text-end dir-ltr" dir="ltr" placeholder="UUID Code">
								<button onclick="myFunctionUuid()" class="btn btn-Square btn-Square-left btn-outline-primary" type="button" id="btn-user-uuid">
									<i class="fa fa-copy"></i>
								</button>
							</div>
						</div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group mb-2">
                            <label for="usersubs" class="form-label form-label-span">
								<span class="label-span" dir="rtl">: Sub کد</span>
							</label>
							<div class="input-group">
								<span class="btn-clearField" onclick="document.getElementById('input-users-info').value = ''"></span> 
								<input id="input-users-info" type="text" name="usersubs" value="<?= $usersubs ?>" class="form-control text-end dir-ltr" dir="ltr" placeholder="Subscription Code">
								<button onclick="myFunctionInfo()" class="btn btn-Square btn-Square-left btn-outline-primary" type="button" id="btn-users-info">
									<i class="fa fa-copy"></i>
								</button>
							</div>	
                        </div>
                    </div>
				</div>
                <div class="row-user">
                    <div class="col-md-6">
                        <div class="form-group mb-2">
                            <label for="limit_users" class="form-label">تعداد کاربران همزمان</label>
                            <input type="number" min="1" value="<?= $concurrentUsers ?>" name="limit_users" class="form-control" placeholder="تعداد کاربر را وارد کنید" required>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group mb-2">
                            <label fotn class="form-label">مقدار ترافیک (0 نامحدود)</label>
                            <div class="input-group">
                                <input type="number" value="<?= $traffic ?>" name="traffic" min="0" class="form-control" placeholder="مقدار ترافیک قابل مصرف را وارد کنید" required>
                                <span class="btn btn-Square btn-Square-left input-group-text">GB</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row-user">
                    <?php if (!$startDate) { ?>
                        <div class="col-md-6 mb-2">
                            <div class="form-group">
                                <label for="expiry_type" class="form-label">زمان انقضاء</label>
                                <div class="form-control">
									<div class="form-check form-check-inline mb-0">
                                        <input class="form-check-input" type="radio" name="expiry_type" value="date" required <?= $expiryType == "date" ? "checked" : "" ?>>
                                        <label class="form-check-label  mb-0">بر اساس تاریخ</label>
                                    </div>
                                    <div class="form-check form-check-inline mb-0">
                                        <input class="form-check-input" type="radio" name="expiry_type" value="days" required <?= $expiryType == "days" ? "checked" : "" ?>>
                                        <label class="form-check-label  mb-0">براساس روز (از اولین اتصال)</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php } ?>
                    <div class="col-md-6" id="expiry-by-days" style="display: <?= $expiryType == "days" ? "block" : "none" ?>;">
                        <div class="mb-2">
                            <div class="form-group mb-0">
                                <label for="exp_days" class="form-label">زمان انقضاء (از اولین اتصال)</label>
                                <div class="input-group">
                                    <input type="number" min="1" name="exp_days" value="<?= $expiryDays ?>" class="form-control" placeholder="تعداد روز" required>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6" id="expiry-by-date" style="display: <?= $expiryType == "date" ? "block" : "none" ?>">
                        <div class="form-group mb-0">
                            <label for="exp_date" class="form-label">تاریخ انقضاء</label>
                            <input type="text" class="form-control datepicker" name="exp_date" value="<?= $endDateJD ?>" placeholder="تاریخ را انتخاب کنید" required>
                        </div>
                    </div>
                </div>
                <div class="form-group mb-2">
                    <label fotn class="form-label">توضیحات</label>
                    <textarea name="desc" class="form-control" placeholder="متن توضیحات را وارد کنید"><?= $desc ?></textarea>
                </div>
            </form>
        </div>
        <div class="modal-footer">
            <button class="btn btn-Square-normal btn-Square-pc" id="btn-submit-user" form='user-form'>
				ذخیره
                <?= $userId ? " ویرایش کاربر" : " افزودن کاربر" ?>
            </button>
        </div>
    </div>
</div>

<script>
    var formMode = "<?= !$userId ? "add" : "edit" ?>";
    window.initUsersForm(formMode);
</script>