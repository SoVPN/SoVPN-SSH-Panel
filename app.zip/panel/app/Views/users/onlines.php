<table id="online-users-table" class="table table-striped online-users-table panelUserOnline loginPanel-close">
	<thead>
		<tr>
			<th>
				<p class="user-online-head">User Online</p>
				<div class="onlineToggel"></div>
			</th>
		</tr>
	</thead>
	<tbody id="panCounter" class="userConter tbody-user-online">
		<?php
		$num = 0;
		foreach ($onlineUsers as $username => $userData) {
			$num++;
			$pids = [];
		?>
		<tr class="panCounter">
			<td class="td-kill td-kill-user">
				<button class="btn btn-warning btn-Square btn-action btn-kill-user btn-Square-normal" data-pid="<?= implode(",", $pids) ?>">
					<i class="fa fa-users-slash"></i>
					<!--?= inlineIcon("users-slash") ?-->
				</button>
			</td>
			<td class="td-kill-ip-user">
				<div class="d-flex flex-column m-auto d-flex-userOnline" style="max-width: 150px;">
					<div class="d-flex justify-content-between mb-1 align-items-center">
						<button class="btn btn-danger btn-action btn-Square btn-Square-normal btn-sm btn-kill-user" data-pid="<?= $data["pid"] ?>">
							<i class="fa fa-user-slash"></i>
							<!--?= inlineIcon("user-slash") ?-->
						</button>
					</div>
				</div>
			</td>
			<td class="td-ip td-user-num-online">
				<span class="badge p-2 text-bg-<?= count($userData) > 1 ? "danger" : "primary" ?>">
					<?= count($userData) ?>
				</span>
			</td>
			<td class="td-name td-name-side"><?= ucfirst($username) ?></td>
		</tr>
<?php	}	?>
	</tbody>
</table>
