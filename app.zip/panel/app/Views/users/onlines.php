<div id="onlineUserList">
	<div class="userOnlineHead">
		<label id="mobCounter" for="navBtnUser">
			<span class="sidebar-counter-num" style="background:var(<?= userOnlineToggle() ?>)!important;"><?= userOnlineCounter() ?></span>
		</label>
		<div class="onlineText-cover">
			<p class="user-online-head">User Online</p>
		</div>
	</div>
	<div class="onlineUserList">
		<table id="online-users-table" class="table table-striped online-users-table panelUserOnline loginPanel-close">
			<tbody id="panCounter" class="userConter tbody-user-online">
				<?php
				$num = 0;
				foreach ($onlineUsers as $username => $userData) {
					$num++;
					$pids = [];
				?>
				<tr class="panCounter">
					<!--td class="td-kill td-kill-user">
						<button class="btn btn-warning btn-Square btn-action btn-kill-user btn-Square-normal" data-pid="<--?= implode(",", $pids) ?>">
							<i class="fa fa-users-slash"></i>
						</button>
					</td>
					<td class="td-kill-ip-user">
						<div class="d-flex flex-column m-auto d-flex-userOnline" style="max-width: 150px;">
							<div class="d-flex justify-content-between mb-1 align-items-center">
								<button class="btn btn-danger btn-action btn-Square btn-Square-normal btn-sm btn-kill-user" data-pid="<--?= $data["pid"] ?>">
									<i class="fa fa-user-slash"></i>
								</button>
							</div>
						</div>
					</td-->
					<td class="td-ip td-user-num-online">
						<span class="badge p-2 text-bg-<?= count($userData) > 1 ? "danger" : "primary" ?>">
							<?= count($userData) ?>
						</span>
					</td>
					<td class="td-name td-name-side"><?= ucfirst($username) ?></td>
				</tr>
		<?php	}	?>
			</tbody>
		</table>
	</div>
</div>
