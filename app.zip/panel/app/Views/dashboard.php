<div id="cardDash" class="row-main row gx-3">
	<div class="card-progress-bar card-body custom-card card">
		<?php include('users/progress.php'); ?>
		<div class="dash-sp-progress">
			<div id="ramProgress" class="progressPack">
				<svg  class="dashProgress" height="100%" width="100%" viewbox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
					<path class="progressBarLine" transform="translate(-5,-7)" stroke="var(--so-prog-back)" stroke-linecap="round" d="M 30,90 A40,40 0 1,1 80,90" fill='none' />
					<g id="ramGroup">
						<path id="ramLine" class="progressBarLine" transform="translate(-5,-7)" stroke="var(--so)" fill='none' stroke="url(#ramGradient)" stroke-dasharray="198" class="purple" style="stroke-dashoffset:<?= $ramNum = 100 - (($ramData['usage_percent'] * 1.9) - 100) ?>px;" stroke-linecap="round" d="M30,90 A40,40 0 1,1 80,90" />
					</g>
				</svg>
				<div class="progressInfo">
					<div class="ramAvg" class="progress-num ramAvg"><?= $ramData['usage_percent'] ?>%</div>
					<div class="progress-total"><?= $ramData['total'] ?></div>
					<h6 class="progressTitle">RAM</h6>
				</div>
			</div>	
			<div id="cpuProgress" class="progressPack">
				<svg  class="dashProgress" height="100%" width="100%" viewbox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
						<path class="progressBarLine" transform="translate(-5,-7)" stroke="var(--so-prog-back)" stroke-linecap="round" d="M30,90 A40,40 0 1,1 80,90" fill='none' />
					<g id="cpuGroup">
						<path id="cpuLine" class="progressBarLine" transform="translate(-5,-7)" stroke="var(--so)" fill='none' stroke="url(#cpuGradient)" stroke-dasharray="198" class="purple" style="stroke-dashoffset:<?= $cpuNum = 100 - (($cpuData['loadAvg'] * 1.9) - 100) ?>px;" stroke-linecap="round" d="M30,90 A40,40 0 1,1 80,90" />
					</g>
				</svg>
				<div class="progressInfo">
					<div id="cpuAvg" class="progress-num cpuAvg"><?= $cpuData['loadAvg'] ?>%</div>
					<div class="progress-total"><?= $cpuData['totalCores'] ?> Core</div>
					<h6 class="progressTitle">CPU</h6>
				</div>
			</div>	
			<div id="hddProgress" class="progressPack">
				<svg  class="dashProgress" height="100%" width="100%" viewbox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
					<path class="progressBarLine" transform="translate(-5,-7)" stroke="var(--so-prog-back)" stroke-linecap="round" d="M30,90 A40,40 0 1,1 80,90" fill='none' />
					<g id="hddGroup">
						<path id="hddLine" class="progressBarLine" transform="translate(-5,-7)" stroke="var(--so)" fill='none' stroke="url(#hddGradient)" stroke-dasharray="198" class="purple" style="stroke-dashoffset:<?= $hddNum = 100 - (($diskData['usage_percent'] * 1.9) - 100) ?>px;" stroke-linecap="round" d="M30,90 A40,40 0 1,1 80,90" />
					</g>
				</svg>
				<div class="progressInfo">
					<div class="hddAvg" class="progress-num hddAvg"><?= $diskData['usage_percent'] ?>%</div>
					<div class="progress-total"><?= $diskData['total'] ?></div>
					<h6 class="progressTitle">HDD</h6>
				</div>
			</div>
		</div>
	</div>
	<div class="card-info-pc card-dash-info dash-card-a">
		<div>
			<h6 class="card-dash-h6">آنلاین</h6>
			<a class="Counter" href="<?= baseUrl('users/online') ?>">
				<h5 class="card-dash-h5"><?= userOnlineCounter() ?></h5>
			</a>
		</div>
		<div>
			<h6 class="card-dash-h6">کاربران</h6>
			<a href="<?= baseUrl('users') ?>">
				<h5 class="card-dash-h5"><?= $totalData['users']['all'] ?></h5>
			</a>
		</div>
		<div>
			<h6 class="card-dash-h6">فعال</h6>
			<a href="<?= baseUrl('users?status=active') ?>">
				<h5 class="card-dash-h5"><?= $totalData['users']['active'] ?></h5>
			</a>
		</div>
		<div>
			<h6 class="card-dash-h6">غیر فعال</h6>
			<a href="<?= baseUrl('users?status=de_active') ?>">
				<h5 class="card-dash-h5"><?= $totalData['users']['inActive'] ?></h5>
			</a>
		</div>
		<div>
			<h6 class="card-dash-h6">اتمام ترافیک</h6>
			<a href="<?= baseUrl('users?status=expiry_traffic') ?>">
				<h5 class="card-dash-h5"><?= $totalData['users']['expiryTraffic'] ?></h5>
			</a>
		</div>
		<div>
			<h6 class="card-dash-h6">انقضای تاریخ</h6>
			<a href="<?= baseUrl('users?status=expiry_date') ?>">
				<h5 class="card-dash-h5"><?= $totalData['users']['expiryDate'] ?></h5>
			</a>
		</div>
		<div>
			<h6 class="card-dash-h6 small upTime"><?= $uptime ?></h6>
			<button title="ریبوت سیستم عامل" class="rounded-circle btn btn-Square btn-sm btn-delete btn-Square-delete btn-reboot-server">
				<i class="fa fa-power-off card-dash-h5"></i>
			</button>
		</div>
	</div>
</div>
<?php include('layouts/sections/mobile-swiper.php'); ?>

<?php include('users/index.php'); ?>
<?php include('users/onlines.php'); ?>


<!--script type="text/javascript">
//		var intervalId = 0;
//		intervalId = setInterval(ifyAjax, 2000);
		
//		setInterval(function() {
//			$("#panCounter").load(window.location + " .panCounter");
//			$("#sidCounter").load(window.location + " .sidCounter");
//			$(".cpuAvg").load(window.location + " .cpuAvg");
//			$("#cpuGroup").load(window.location + " #cpuLine");
//			$("#banner").load(window.location + " .bannerc");
//		}, 2000);
</script-->






		
		
		
		
		
		
		
		