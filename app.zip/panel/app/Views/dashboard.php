<div class="dash-cover ">
	<div id="cardDash" class="row-main gx-3">
		<div class="card-progress-bar card-body custom-card card">
			<div class="dash-sp-progress reboot-server">
				<div id="ramProgress" class="progressPack">
					<div class="divRam">
						<svg  class="dashProgress" height="100%" width="100%" viewbox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
							<path class="progressBarLine" d="M 50,50 m 0,47 a 47,47 0 1 1 0,-94 a 47,47 0 1 1 0,94" stroke="var(--so-prog-back)" stroke-linecap="round" stroke-width="6" fill-opacity="0" class="ant-progress-circle-trail" style="stroke: var(--so-prog-back); stroke-dasharray: 220.31px, 295.31px; stroke-dashoffset: -37.5px; transition: stroke-dashoffset 0.3s ease 0s, stroke-dasharray 0.3s ease 0s, stroke 0.3s ease 0s, stroke-width 0.06s ease 0.3s, opacity 0.3s ease 0s;">
							</path>
							<g id="gRamLine">
								<path id="ramLine" class="ramProgressBarLine" d="M 50,50 m 0,47 a 47,47 0 1 1 0,-94 a 47,47 0 1 1 0,94" stroke="" stroke-linecap="round" stroke-width="6" opacity="1" fill-opacity="0" class="ant-progress-circle-path" style="stroke: var(--so); stroke-dasharray: <?= $ramNum = $ramData['usage_percent'] * 2.2 ?>px, 295.31px; stroke-dashoffset: -37.5px; transition: stroke-dashoffset 0.3s ease 0s, stroke-dasharray 0.3s ease 0s, stroke 0.3s ease 0s, stroke-width 0.06s ease 0.3s, opacity ease 0s;"></path>
							</g>
							<div class="progressInfo">
								<div id="ramAvg" class="progress-num ramAvg"><?= $ramData['usage_percent'] ?>%</div>
								<div class="progress-total"><?= $ramData['total'] ?></div>
								<h6 class="progressTitle">RAM</h6>
							</div>
						</svg>
					</div>
				</div>	
				<div id="cpuProgress" class="progressPack cpuProgressPack">
					<div class="divCpu">
						<svg class="dashProgress" height="100%" width="100%" viewbox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
							<path class="progressBarLine" d="M 50,50 m 0,47 a 47,47 0 1 1 0,-94 a 47,47 0 1 1 0,94" stroke="var(--so-prog-back)" stroke-linecap="round" stroke-width="6" fill-opacity="0" class="ant-progress-circle-trail" style="stroke: var(--so-prog-back); stroke-dasharray: 220.31px, 295.31px; stroke-dashoffset: -37.5px; transition: stroke-dashoffset 0.3s ease 0s, stroke-dasharray 0.3s ease 0s, stroke 0.3s ease 0s, stroke-width 0.06s ease 0.3s, opacity 0.3s ease 0s;">
							</path>
							<g id="gCpuLine">
								<path id="cpuLine" class="cpuProgressBarLine" d="M 50,50 m 0,47 a 47,47 0 1 1 0,-94 a 47,47 0 1 1 0,94" stroke="" stroke-linecap="round" stroke-width="6" opacity="1" fill-opacity="0" class="ant-progress-circle-path" style="stroke: var(--so); stroke-dasharray: <?= $ramNum = $cpuData['loadAvg'] * 2.2 ?>px, 295.31px; stroke-dashoffset: -37.5px; transition: stroke-dashoffset 0.3s ease 0s, stroke-dasharray 0.3s ease 0s, stroke 0.3s ease 0s, stroke-width 0.06s ease 0.3s, opacity ease 0s;"></path>
							</g>
							<div class="progressInfo">
								<div id="cpuAvg" class="progress-num cpuAvg"><?= $cpuData['loadAvg'] ?>%</div>
								<div class="progress-total"><?= $cpuData['totalCores'] ?> Core</div>
								<h6 class="progressTitle">CPU</h6>
							</div>
						</svg>
					</div>
				</div>	
				<div id="hddProgress" class="progressPack" style="z-index:1000;">
					<div class="divHdd">
						<svg  class="dashProgress" height="100%" width="100%" viewbox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
							<path class="progressBarLine" d="M 50,50 m 0,47 a 47,47 0 1 1 0,-94 a 47,47 0 1 1 0,94" stroke="var(--so-prog-back)" stroke-linecap="round" stroke-width="6" fill-opacity="0" class="ant-progress-circle-trail" style="stroke: var(--so-prog-back); stroke-dasharray: 220.31px, 295.31px; stroke-dashoffset: -37.5px; transition: stroke-dashoffset 0.3s ease 0s, stroke-dasharray 0.3s ease 0s, stroke 0.3s ease 0s, stroke-width 0.06s ease 0.3s, opacity 0.3s ease 0s;">
							</path>
							<path id="hddLine" class="progressBarLine" d="M 50,50 m 0,47 a 47,47 0 1 1 0,-94 a 47,47 0 1 1 0,94" stroke="" stroke-linecap="round" stroke-width="6" opacity="1" fill-opacity="0" class="ant-progress-circle-path" style="stroke: var(--so); stroke-dasharray: <?= $diskData['usage_percent'] * 2.2 ?>px, 295.31px; stroke-dashoffset: -37.5px; transition: stroke-dashoffset 0.3s ease 0s, stroke-dasharray 0.3s ease 0s, stroke 0.3s ease 0s, stroke-width 0.06s ease 0.3s, opacity ease 0s;">
							</path>
							<div class="progressInfo">
								<div class="hddAvg" class="progress-num hddAvg"><?= $diskData['usage_percent'] ?>%</div>
								<div class="progress-total"><?= $diskData['total'] ?></div>
								<h6 class="progressTitle">HDD</h6>
							</div>
						</svg>
					</div>
				</div>
			</div>
		</div>
		<div class="card-info-pc card-dash-info dash-card-a">
			<div>
				<h6 class="card-dash-h6">کاربران</h6>
				<a>
					<h5 class="card-dash-h5"><?= $totalData['users']['all'] ?></h5>
				</a>
			</div>
			<div>
				<h6 class="card-dash-h6">فعال</h6>
				<a href="<?= baseUrl('dashboard?status=active') ?>">
					<h5 class="card-dash-h5"><?= $totalData['users']['active'] ?></h5>
				</a>
			</div>
			<div>
				<h6 class="card-dash-h6">غیر فعال</h6>
				<a href="<?= baseUrl('dashboard?status=de_active') ?>">
					<h5 class="card-dash-h5"><?= $totalData['users']['inActive'] ?></h5>
				</a>
			</div>
			<div>
				<h6 class="card-dash-h6">اتمام ترافیک</h6>
				<a href="<?= baseUrl('dashboard?status=expiry_traffic') ?>">
					<h5 class="card-dash-h5"><?= $totalData['users']['expiryTraffic'] ?></h5>
				</a>
			</div>
			<div>
				<h6 class="card-dash-h6">انقضای تاریخ</h6>
				<a href="<?= baseUrl('dashboard?status=expiry_date') ?>">
					<h5 class="card-dash-h5"><?= $totalData['users']['expiryDate'] ?></h5>
				</a>
			</div>
			<?php if ($userRole == "admin") { ?>
			<div>
				<h6 class="card-dash-h6 small upTime">UpTime : <p><?= $uptime ?></p></h6>
			</div>
		<?php } ?>
		</div>
	</div>
	<?php if ($userRole == "admin") { include("layouts/sections/mobile-swiper.php"); } ?>
	<div class="card-header-user-index">
		<?php include("users/index.php"); ?>
	</div>
</div>
<div class="card-index-group">
	<?php include "layouts/sections/pc-swiper.php"; ?>
	<input id="navBtnUser" type="checkbox" style="display:none;" />
	<?php if ($userRole == "admin") { ?><div class="uOnlineList"><?php include("users/onlines.php"); ?></div><?php } ?>
</div>
</div>
<?php if ($userRole == "admin") { include "app/Views/settings/settingstab.php"; } ?>
<?php include "app/Views/layouts/sections/navimenu.php"; ?>
<?php include "app/Views/layouts/sections/sidemenu.php"; ?>

