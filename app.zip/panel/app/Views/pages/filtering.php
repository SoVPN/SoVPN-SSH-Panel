<script language="javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script language="javascript" src="javascripts/jquery.vibrate.min.js"></script>
<script type="text/javascript">
$(document).ready(function () {
  $('#vib1').on('click', function() {
    $('#vib1').vibrate({stopAfterTime:2});
  });

  $('#vib2').on('click', function() {
    $('#vib2').vibrate({stopAfterTime:5, vibrateClass:'redSignal'});
  });

  $('#vib3').on('click', function() {
    $('#vib3').vibrate({stopAfterTime:2, callBack: function() {
      $('#vib3').text('Vibration Done');
    }});
  });
});
</script>

<div id="demoDiv">
  <div class="signals" id="vib1">
    Vibrate me for 2s
  </div>
  <div class="signals" id="vib2">
    Vibrate me for 5s and turn me red
  </div>
  <div class="signals" id="vib3">
    Change my text
  </div>
</div>