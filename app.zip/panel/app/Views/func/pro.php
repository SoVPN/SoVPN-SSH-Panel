<?php

//$cpuNuma = 100 - (($cpuData['loadAvg'] * 1.9) - 100);
//$cpuNumb = 100 - (($cpuData['loadAvg'] * 1.9) - 100);
//$cpuNumc = 100 - (($cpuData['loadAvg'] * 1.9) - 100);
//$cpuNumd = 100 - (($cpuData['loadAvg'] * 1.9) - 100);
//$cpuNume = 100 - (($cpuData['loadAvg'] * 1.9) - 100);
$cpuNuma = $cpuData['loadAvg'];
$cpuNumb = $cpuData['loadAvg'];
$cpuNumc = $cpuData['loadAvg'];
$cpuNumd = $cpuData['loadAvg'];
$cpuNume = $cpuData['loadAvg'];
//$usePro = userOnlineCounter();

$bg_array = array(
    $cpuNuma,
    $cpuNumb,
	$cpuNumc,
	$cpuNumd,
	$cpuNume
);
$bg = array_rand($bg_array, 1);
?>
<div class="banner" style="width:<?php echo $bg_array[$bg];?>;" >
	<div class="txt-subtitle"><?php echo $bg_array[$bg];?></div>
</div>
