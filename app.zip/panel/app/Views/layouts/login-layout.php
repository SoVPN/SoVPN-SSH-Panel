<?php include "sections/head.php"; ?>
    <?php include viewContentPath($viewContent); ?>
<?php include "sections/footer.php"; ?>