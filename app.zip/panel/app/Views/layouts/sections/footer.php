<div class="modal fade" id="ajax-modal-view" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" tabindex="-1">
	<div id="modal-loading-body" style="display: none;">
		<div class="modal-dialog modal-xs">
			<div class="modal-content">
				<div class="modal-body">
					<div class="text-center">
						<div class="spinner-border " role="status"></div>
						<p class="d-block mt-2">در حال بارگذاری...</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
</body>
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-element-bundle.min.js"></script>
<script src="<?= assets("js/bootstrap.bundle.min.js") ?>"></script>
<script src="<?= $mainAppEnqueue["js_url"] ?>"></script>
<?php footerFiles(); ?>
<script>
$(document).ready(function(){
	// Body Settings Class
	if(window.location.pathname == '/dashboard'){
		$('#toggle-pc').addClass('active-btn');
		$('body').addClass('dashboard');
	}
	if(window.location.pathname == '/settings'){
		$('body').addClass('settings');
	}
	if(window.location.pathname == '/admins'){
		$('body').addClass('settings');
	}
	if(window.location.pathname == '/settings/backup'){
		$('body').addClass('settings');
	}
	if(window.location.pathname == '/settings/api'){
		$('body').addClass('settings');
	}
	if(window.location.pathname == '/settings/users-panel'){
		$('body').addClass('settings');
	}
});
</script>
<script>
	function settingsTsb(evt, settingPage) {
		var i, tabcontent, tablinks;
		tabcontent = document.getElementsByClassName("tabcontent");
		for (i = 0; i < tabcontent.length; i++) {
			tabcontent[i].style.display = "none";
		}
		tablinks = document.getElementsByClassName("tablinks");
		for (i = 0; i < tablinks.length; i++) {
			tablinks[i].className = tablinks[i].className.replace(" active", "");
		}
		document.getElementById(settingPage).style.display = "block";
		evt.currentTarget.className += " active";
	}
	document.getElementById("defaultOpen").click();
</script>
</html>
