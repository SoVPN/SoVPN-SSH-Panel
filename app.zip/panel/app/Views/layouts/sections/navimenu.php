<nav class="sovpn-nav" style="z-index:1200;">
	<i class="fa fa-bars navBtnLabel"></i>
	<label class="col-nav col-nav-right" for="modalDashClose">
		<a href="<?= baseUrl("logout") ?>" class="nav-link-power-off">
			<i class="fa fa-power-off icon menu-icon"></i>
		</a>
	</label>
	<label class="col-nav">
		<div class="toggle-switch">
			<button type="button" id="btn-toggle-theme" class="btn btn-toggle-theme btn-sm switch" data-theme="<?= $activeTheme ?>" aria-pressed="false">
				<?= inlineIcon($activeTheme == "dark") ?>
				<span class=""></span>
			</button>
		</div>
	</label>
	<?php if ($userRole == "admin") { ?>
	<label class="col-nav" for="modalDashClose">
		<i class="fa fa-gear"></i>
	</label>
	<?php } ?>
	<div class="col-nav add-user">
		<div class="col-nav-add-user">
			<label class="btnAddUser btnRight" for="btnAddUser">
				<i class="fa fa-user-plus fa-add-user"></i>
			</label>
			<label class="btnAddUser btnLeft" for="btnAddUsers">
				<p class="btn-users-plus">+</p>
				<i class="fa fa-users fa-add-user"></i>
			</label>
		</div>
		<i class="fa fa-user-plus"></i>
	</div>
	<?php if ($userRole == "admin") { ?>
	<label class="col-nav col-nav-online mobile" for="navBtnUser">
		<div class="navCounter" style="background:var(<?= userOnlineToggle() ?>)!important;"><?= userOnlineCounter() ?></div>
	</label>
	<label class="col-nav col-nav-left">
		<div>
			<?= btnRebootServer(); ?>
		</div>
	</label>
	<?php } ?>
</nav>