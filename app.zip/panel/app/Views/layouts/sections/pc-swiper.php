<div class="card-dash-info-pc">
	<div>
		<h6 class="card-dash-h6">امروز</h6>
		<h5 class="card-dash-h5"><?= getCurrentDate() ?></h5>
	</div>
	<div>
		<h6 class="card-dash-h6">ترافیک سرور</h6>
		<h5 class="card-dash-h5"><?= $serverTraffic["total"] ?></h5>
	</div>
	<div>
		<h6 class="card-dash-h6">ترافیک کاربران</h6>
		<h5 class="card-dash-h5"><?= $userTraffic["total"] ?></h5>
	</div>
	<div>
		<h6 class="card-dash-h6">IP v4</h6>
		<h5 class="card-dash-h5"><?= getServerIp() ?></h5>
	</div>
	<div>
		<h6 class="card-dash-h6">IP v6</h6>
		<h5 class="card-dash-h5 ipv6-line"><?= getServerIpV6() ?></h5>
	</div>
	<div>
		<h6 class="card-dash-h6">IP Login</h6>
		<h5 class="card-dash-h5"><?= userIPAddress() ?></h5>
	</div>
</div>