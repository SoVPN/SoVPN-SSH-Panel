<div id="swiper-pack" class="swiper-pack">
	<div class="arrow arrow-left"></div>
	<div class="arrow arrow-right"></div>
	<swiper-container class="mySwiper" space-between="30" loop="true">
		<swiper-slide style="padding:0 5px">
			<div class="card-dash-info dash-card-a slide">
				<div>
					<h6 class="card-dash-h6">کاربران</h6>
					<a>
						<h5 class="card-dash-h5"><?= $totalData["users"]["all"] ?></h5>
					</a>
				</div>
				<div>
					<h6 class="card-dash-h6">فعال</h6>
					<a href="<?= baseUrl("dashboard?status=active") ?>">
						<h5 class="card-dash-h5"><?= $totalData["users"]["active"] ?></h5>
					</a>
					<h6 class="card-dash-h6">غیر فعال</h6>
					<a href="<?= baseUrl("dashboard?status=de_active") ?>">
						<h5 class="card-dash-h5"><?= $totalData["users"]["inActive"] ?></h5>
					</a>
				</div>
				<div>
					<h6 class="card-dash-h6">اتمام ترافیک</h6>
					<a href="<?= baseUrl("dashboard?status=expiry_traffic") ?>">
						<h5 class="card-dash-h5"><?= $totalData["users"]["expiryTraffic"] ?></h5>
					</a>
					<h6 class="card-dash-h6">انقضای تاریخ</h6>
					<a href="<?= baseUrl("dashboard?status=expiry_date") ?>">
						<h5 class="card-dash-h5"><?= $totalData["users"]["expiryDate"] ?></h5>
					</a>
				</div>
			</div>	
		</swiper-slide>
		<swiper-slide style="padding:0 5px">
			<div class="card-dash-info dash-card-b slide">
				<div>
					<h5 class="card-dash-h5"><?= getServerIp() ?></h5>
					<h6 class="card-dash-h6">IP v4</h6>
				</div>
				<div>
					<h5 class="card-dash-h5"><?= getServerIpV6() ?></h5>
					<h6 class="card-dash-h6">IP v6</h6>
				</div>
				<div>
					<h5 class="card-dash-h5"><?= userIPAddress() ?></h5>
					<h6 class="card-dash-h6">IP Login</h6>
				</div>
			</div>	
		</swiper-slide>	
		<swiper-slide style="padding:0 5px">
			<div class="card-dash-info dash-card-b slide">
				<div>
					<h5 class="card-dash-h5"><?= getServerName() ?></h5>
					<h6 class="card-dash-h6">Domain</h6>
				</div>
				<div>
					<h5 class="card-dash-h5"><?= getenv("PORT_SSH"); ?></h5>
					<h6 class="card-dash-h6">SSH Port</h6>
				</div>
				<div>
					<h5 class="card-dash-h5"><?= getenv("PORT_UDP"); ?></h5>
					<h6 class="card-dash-h6">UDP Port</h6>
				</div>
			</div>	
		</swiper-slide>	
		<swiper-slide style="padding:0 5px">
			<div class="card-dash-info dash-card-d slide">
				<div>
					<h6 class="card-dash-h6">امروز</h6>
					<h5 class="card-dash-h5"><?= getCurrentDate() ?></h5>
				</div>
				<div>
					<h6 class="card-dash-h6">ترافیک سرور</h6>
					<h5 class="card-dash-h5"><?= $serverTraffic["total"] ?></h5>
				</div>
				<div>
					<h6 class="card-dash-h6">ترافیک کاربران</h6>
					<h5 class="card-dash-h5"><?= $userTraffic["total"] ?></h5>
				</div>
			</div>	
		</swiper-slide>	
	</swiper-container>
</div>
