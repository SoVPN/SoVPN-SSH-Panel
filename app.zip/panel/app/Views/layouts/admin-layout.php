<?php include "sections/head.php"; ?>
	
	<div class="content">

		<?php include viewContentPath($viewContent); ?>
		
	</div>
	
<?php include "sections/footer.php"; ?>