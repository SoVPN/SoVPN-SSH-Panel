<div class="main-content-wrap d-flex flex-column h-100">
	<div class="flex-shrink-0 mb-2">
		<div class="container-fluid mb-1">
			<header class="FrameHiden main-header d-flex justify-content-between p-1">
				<div class="header-toggle d-block d-lg-none ">
					<button class="menu-toggle bt-sm  btn btn-primary rounded-circle ">
						<i class="fa fa-bars align-middle"></i>
					</button>
				</div>
			</header>
			<div class="main-content pt-4 main-content-admin">
				<div class="card padding-bottom">
					<div class="has-actions-adminList">
						<div class="actions">
							<button class="btn btn-Square-normal btn-Square-pc btn-Square-margin-pc btn-Square-margin-mobile btn-ajax-views" data-url="admins/add">
								افزودن
							</button>
						</div>
					</div>
					<div class="card-body table-responsive">
						<table id="admins-table" class="table " style="width: 100%;">
							<tbody>
				
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
