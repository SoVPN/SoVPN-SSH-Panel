<input type="checkbox" id="modalDashClose" style="display:none;"/>
<label id="modalDashPanel" class="modalDashPanel" for="modalDashClose">
	<div class="modalSettings">
		<div id="tabs" class="tabs">
			<div class="tab">
				<div class="tabs-menu">
					<button class="tablinks panel" onclick="settingsTsb(event, 'MainTab')" id="defaultOpen"><i class="fa fa-gear"></i>تنظیمات اصلی</a></button>
					<button class="tablinks panel" onclick="settingsTsb(event, 'BackUpTab')"><i class="fa fa-database"></i>پشتیبان گیری</a></button>
					<button class="tablinks panel" onclick="settingsTsb(event, 'ApiTab')"><i class="fa fa-server"></i>تنظیمات API</a></button>
					<button class="tablinks panel" onclick="settingsTsb(event, 'UsersTab')"><i class="fa fa-users"></i>پنل کاربران</a></button>
					<button class="tablinks panel" onclick="settingsTsb(event, 'AdminsTab')"><i class="fa fa-users"></i>همکاران</a></button>
					<label class="tabClose btn-delete" for="modalDashClose"><i class="fa fa-close"></i></label>
				</div>
			</div>
			<div id="MainTab" class="tabcontent panel">
				<iframe id="MainTabFrame" src="<?= baseUrl("settings") ?>" title="description" frameborder="0" style="height:100%;width:100%" height="100%" width="100%" scrolling="no" seamless="seamless" ></iframe>
			</div>
			<div id="BackUpTab" class="tabcontent panel">
				<iframe src="<?= baseUrl("settings/backup") ?>" title="description" frameborder="0" style="height:100%;width:100%" height="100%" width="100%" scrolling="no" seamless="seamless" ></iframe>
			</div>
			<div id="ApiTab" class="tabcontent panel">
				<iframe src="<?= baseUrl("settings/api") ?>" title="description" frameborder="0" style="height:100%;width:100%" height="100%" width="100%" scrolling="no" seamless="seamless" ></iframe>
			</div>
			<div id="UsersTab" class="tabcontent panel">
				<iframe src="<?= baseUrl("settings/users-panel") ?>" title="description" frameborder="0" style="height:100%;width:100%" height="100%" width="100%" scrolling="no" seamless="seamless" ></iframe>
			</div>
			<div id="AdminsTab" class="tabcontent panel">
				<iframe src="<?= baseUrl("admins") ?>" title="description" frameborder="0" style="height:100%;width:100%" height="100%" width="100%" scrolling="no" seamless="seamless" ></iframe>
			</div>
		</div>
	</div>
</label>