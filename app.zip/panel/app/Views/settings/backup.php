<div id="backUpBody" class="row-tabs column-gap">
    <div class="col-md-6 row-gap flex" style="margin-bottom:15px;">
        <div class="card row-gap">
            <div class="card-header card-header-settings">
                <h6 class="mb-0">بارگذاری فایل پشتیبان</h6>
            </div>
            <div class="card-body">
                <form id="import-form" method="post" action="<?= baseUrl("ajax/settings/backup/import") ?>">
                    <div class="form-group">
                        <label>انتخاب از پنل</label>
                        <select class="form-select" name="import_from" required>
                            <option value="current">پنل فعلی</option>
                            <option value="shahan">پنل شاهان</option>
                            <option value="xpanel">ایکس پنل</option>
                            <option value="dragon">پنل دراگون</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>انتخاب فایل دیتابیس <span class="unicode-bidi-plain">(*.sql)</span></label>
						<label class="labelBackUpbtn" for="backUpbtn">
							<div></div>
							<p>انتخاب فایل</p>
						</label>
						<input id="backUpbtn" type="file" accept=".sql" name="sql_file" class="form-control" required />
                    </div>
                    <div class="alert alert-warning">
                        <p class="mb-0 fw-bold">به نکات زیر توجه کنید</p>
                        <ul>
                            <li>
                                در صورتی که فایل پشتیبان از پنل فعلی باشد تمام جدوال جایگزین میشوند.
                                و اگر اطلاعاتی از قبل در پنل داشته باشید تماما حذف میشوند
                            </li>
                            <li>
                                در صورتی که فایل پشتیبان از پنل های دیگری باشد مثل شاهان یا ایکس پنل باشد فقط محتوای جدوال users , traffic اضافه میشود
                                <br />
                                 در صورتی که که کاربری از قبل وجود داشته باشد اطلاعات کاربر جدید جایگزین آن 
                                 <br/>
                                 <span class="text-danger">نمی شود!</span>
                            </li>
                        </ul>
                    </div>
                    <div class="text-center">
                        <button type="submit" class="btn btn-Square-normal btn-Square-pc">
                            ایمپورت
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="col-md-6 row-gap flex">
        <div class="card row-gap flex">
            <div class="card-header card-header-settings">
                <h6 class="mb-0">پشتیبان گیری</h6>
            </div>
            <div class="card-body">
				<div class="modalFooterTabs">
					<button id="create-bkp-btn" class="btn btn-Square-normal btn-Square-pc">
						پشتیبان گیری
					</button>
				</div
                <div class="border-bottom my-2"></div>
                <table class="table table-stripe" id="backup-table">
                    <thead>
                        <tr>
                            <th>ردیف</th>
                            <th>نام</th>
                            <th>تاریخ ایجاد</th>
                            <th class="th-bachup" style="max-width:84px!important">عملیات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        foreach ($backupFiles as $key => $file) {
                        ?>
                            <tr class="bkp-row" data-name="<?= $file["name"] ?>">
                                <td><?= $key + 1 ?></td>
                                <td><?= $file["name"] ?></td>
                                <td><?= $file["date"] ?></td>
                                <td class="btns-backup">
                                    <a href="<?= $file["url"] ?>" target="_blank" class="btn btn-Square btn-Square-normal">
										<i class="fa fa-download"></i>
                                    </a>
                                    <button class="btn btn-Square btn-Square-normal btn-delete btn-margin btn-delete-bkp" data-name="<?= $file["name"] ?>">
										<i class="fa fa-trash"></i>
                                    </button>
                                </td>
                            </tr>
                  <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-md-4"></div>
	<div class="formBottomPadding"></div>
</div>