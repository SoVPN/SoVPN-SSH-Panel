<div class="main-content-wrap d-flex flex-column h-100">
	<div class="flex-shrink-0 mb-2">
		<div class="container-fluid mb-1">
			<button class="menu-toggle bt-sm  btn btn-primary rounded-circle "><?= inlineIcon("bars","align-middle") ?></button>
			<div class="main-content pt-4 main-content-admin">
				<div class="card">
					<div class="card-body">
						<ul class="nav nav-tabs mb-4">
							<li class="nav-item">
								<a class="nav-link <?= $activeTab == "main" ? "active" : "" ?>" href="<?= baseUrl("settings") ?>">
									<i class="fa fa-gear"></i>
									تنظیمات اصلی
								</a>
							</li>
							<li class="nav-item">
								<a class="nav-link <?= $activeTab == "backup" ? "active" : "" ?>" href="<?= baseUrl("settings/backup") ?>">
									<i class="fa fa-database"></i>
									پشتیبان گیری
								</a>
							</li>
							<li class="nav-item">
								<a class="nav-link <?= $activeTab == "api" ? "active" : "" ?>" href="<?= baseUrl("settings/api") ?>">
									<i class="fa fa-server"></i>
									تنظیمات API
								</a>
							</li>
							<li class="nav-item">
								<a class="nav-link <?= $activeTab == "users_panel" ? "active" : "" ?>" href="<?= baseUrl("settings/users-panel") ?>">
									<i class="fa fa-users"></i>
									پنل کاربران
								</a>
							</li>
						</ul>

						<div class="tab-pane fade show active">
						<?php if (file_exists(__DIR__ . DS . "$activeTab.php")) {
								require_once "$activeTab.php";
							} ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>