<div class="card card-settings">
	<div class="card-body card-body-settings">
		<ul class="nav nav-tabs mb-4 nav-hiden">
			<li class="nav-item">
				<a class="nav-link <?= $activeTab == "main" ? "active" : "" ?>" href="<?= baseUrl("settings") ?>">
					<i class="fa fa-gear"></i>
					<p style="margin:0;padding:0;">تنظیمات اصلی</p>
				</a>
			</li>
			<li class="nav-item">
				<a class="nav-link <?= $activeTab == "backup" ? "active" : "" ?>" href="<?= baseUrl("settings/backup") ?>">
					<i class="fa fa-database"></i>
					<p style="margin:0;padding:0;">پشتیبان گیری</p>
				</a>
			</li>
			<li class="nav-item">
				<a class="nav-link <?= $activeTab == "api" ? "active" : "" ?>" href="<?= baseUrl("settings/api") ?>">
					<i class="fa fa-server"></i>
					<p style="margin:0;padding:0;">تنظیمات API</p>
				</a>
			</li>
			<li class="nav-item">
				<a class="nav-link <?= $activeTab == "users_panel" ? "active" : "" ?>" href="<?= baseUrl("settings/users-panel") ?>">
					<i class="fa fa-users"></i>
					<p style="margin:0;padding:0;">پنل کاربران</p>
				</a>
			</li>
		</ul>
		<div class="tab-pane fade show active">
		<?php if (file_exists(__DIR__ . DS . "$activeTab.php")) {
				require_once "$activeTab.php";
			} ?>
		</div>
	</div>
</div>