<?php

/**
 * By SoVPN
 * Github: https://github.com/SoVPN
 */

$apiRoutes =  $app->group('/api/v1', function () use ($app) {
        
});

$apiRoutes->add(new \App\Middlewares\ApiAuth($container));
