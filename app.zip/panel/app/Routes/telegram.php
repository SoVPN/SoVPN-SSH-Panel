<?php

/**
 * By SoVPN
 * Github: https://github.com/SoVPN
 */

$telegramRoutes =  $app->group('/telegram', function () use ($app) {
    $app->post('', 'App\Controllers\Telegram\Main:handleRequest');
});
