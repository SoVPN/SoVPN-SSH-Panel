<?php

/**
 * By SoVPN
 * Github: https://github.com/SoVPN
 */

namespace App\Controllers;

use \App\Libraries\UserShell;

class Pages extends BaseController
{

    public function filtering($request, $response, $args)
    {
		
		
        $this->data["activeMenu"]   = "filtering";
		$status     = $request->getQueryParam("status");

        $viewData = [];
        $viewData["pageTitle"]      = "وضعیت فیلترینگ";
        $viewData["viewContent"]    = "pages/filtering.php";
		$viewData["activePage"]	    = "pages/page.php";
		$viewData["activePage"]     = "pages/progressbar.php";
		$viewData["activePage"]     = "users/online.php";
		$viewData["activePage"]     = "users/index.php";
        $viewData["activePage"]     = "filtering";
		$viewData["activePage"]     = "dashboard";
		$viewData["activeMenu"]     = "users";
        $viewData["activePage"]     = "users";
		
		$uModel      = new \App\Models\Users();
        $tModel      = new \App\Models\Traffics();
        $userInfo    = $request->getAttribute('userInfo');
		$userRole    = $userInfo->role;
        $userName    = $userInfo->username;
		$adminRole   = getAdminRole();
        $onlineUsers = UserShell::onlineUsers();
		$accessUsers = $uModel->adminAccessUsers();
        

        $totalUsers                 = $uModel->totalUsers(null, $userRole, $userName);
        $totalActiveUsers           = $uModel->totalUsers("active", $userRole, $userName);
        $totalInActiveUsers         = $uModel->totalUsers("de_active", $userRole, $userName);
        $totalExpiryTrafficUsers    = $uModel->totalUsers("expiry_traffic", $userRole, $userName);
        $totalExpiryDateUsers       = $uModel->totalUsers("expiry_date", $userRole, $userName);

        $viewData["totalData"] = [
            "users" => [
                "all"               => $totalUsers,
                "active"            => $totalActiveUsers,
                "inActive"          => $totalInActiveUsers,
                "expiryTraffic"     => $totalExpiryTrafficUsers,
                "expiryDate"        => $totalExpiryDateUsers,
                "online"            => UserShell::totalOnlineUsers(),
            ],

        ];

        $viewData["ramData"]        = UserShell::ramData();
        $viewData["cpuData"]        = UserShell::cpuData();
        $viewData["diskData"]       = UserShell::diskData();
        $viewData["uptime"]         = UserShell::serverUptime();
        $viewData["serverTraffic"]  = UserShell::serverTraffic();
		$viewData["userTraffic"]    = $tModel->totalData();
		$viewData["onlineUsers"]    = $onlineUsers;
		
        $this->render($viewData);
	}
}
