<?php

/**
 * By SoVPN
 * Github: https://github.com/SoVPN
 */

namespace App\Controllers;

use \App\Libraries\UserShell;


class Dashboard extends BaseController
{
	
	public function logout($request, $response, $args)
    {
        container()->session->delete('admin_login');
        container()->session->delete('userInfo');

        return $response->withHeader('Location', baseUrl('login'));
    }

    public function notFoundPage($request, $response)
    {
        enqueueStyleHeader(assets("css/404.css"));

        $response = new \Slim\Http\Response(404);
        $this->setResponse($response);
        $this->templateName = "layouts/404-layout.php";
        $viewData = array();
        $viewData["pageTitle"] = "404";
        return $this->render($viewData);
    }

    public function index($request, $response, $args)
    {
		enqueueScriptFooter(assets("vendor/jquery-validate/jquery.validate.min.js"));
        enqueueScriptFooter(assets("vendor/datepicker/datepicker.min.js"));
        enqueueScriptFooter(assets("vendor/datatable/datatables.js"));
		enqueueScriptFooter(assets("js/sovpn.js"));

        enqueueStyleHeader(assets("vendor/datepicker/datepicker.min.css"));
        enqueueStyleHeader(assets("vendor/datatable/datatables.css"));
		
		$status     = $request->getQueryParam("status");

        $viewData = [];
		$viewData["activeStatus"]   = $status;
        $viewData["pageTitle"]      = "داشبورد";
        $viewData["viewContent"]    = "dashboard.php";
		$viewData["activePage"]     = "dashboard";
		$viewData["activeMenu"]     = "dashboard";
		$viewData["activeTab"]      = "main";
		$viewData["activeMenu"]     = "users";
		$viewData["activeTab"]      = "backup";
		

        

        $uModel      = new \App\Models\Users();
        $tModel      = new \App\Models\Traffics();
		$bModel      = new \App\Models\Backup($this);
        $backupFiles = $bModel->getUserBackups();
        $userInfo    = $request->getAttribute('userInfo');
		$userRole    = $userInfo->role;
        $userName    = $userInfo->username;
        $onlineUsers = UserShell::onlineUsers();
		$accessUsers = $uModel->adminAccessUsers();
        

        $totalUsers                 = $uModel->totalUsers(null, $userRole, $userName);
        $totalActiveUsers           = $uModel->totalUsers("active", $userRole, $userName);
        $totalInActiveUsers         = $uModel->totalUsers("de_active", $userRole, $userName);
        $totalExpiryTrafficUsers    = $uModel->totalUsers("expiry_traffic", $userRole, $userName);
        $totalExpiryDateUsers       = $uModel->totalUsers("expiry_date", $userRole, $userName);

        $viewData["totalData"] = [
            "users" => [
                "all"               => $totalUsers,
                "active"            => $totalActiveUsers,
                "inActive"          => $totalInActiveUsers,
                "expiryTraffic"     => $totalExpiryTrafficUsers,
                "expiryDate"        => $totalExpiryDateUsers,
                "online"            => UserShell::totalOnlineUsers(),
            ],

        ];
        $viewData["ramData"]        = UserShell::ramData();
        $viewData["cpuData"]        = UserShell::cpuData();
        $viewData["diskData"]       = UserShell::diskData();
        $viewData["uptime"]         = UserShell::serverUptime();
        $viewData["serverTraffic"]  = UserShell::serverTraffic();
        $viewData["userTraffic"]    = $tModel->totalData();
		$viewData["onlineUsers"]    = $onlineUsers;
		$viewData["backupFiles"]    = $backupFiles;
        $this->render($viewData);
    }

}
