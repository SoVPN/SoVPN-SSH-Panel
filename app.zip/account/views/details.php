<?php
$userId             = getArrayValue($userInfo, "id");
$username           = getArrayValue($userInfo, "username");
$password           = getArrayValue($userInfo, "password");
$email              = getArrayValue($userInfo, "email");
$mobile             = getArrayValue($userInfo, "mobile");
$traffic            = getArrayValue($userInfo, "format_traffic");
$startDate          = getArrayValue($userInfo, "start_date");
$endDate            = getArrayValue($userInfo, "end_date");
$expiryDays         = getArrayValue($userInfo, "expiry_days");
$expiryType         = getArrayValue($userInfo, "expiry_type");
$mobilebrand        = getArrayValue($userInfo, "mobilebrand");
$operator           = getArrayValue($userInfo, "operator");
$desc               = getArrayValue($userInfo, "desc");
$concurrentUsers    = getArrayValue($userInfo, "limit_users");
$consumerTraffic    = getArrayValue($userInfo, "format_consumer_traffic");
$endDateJD          = getArrayValue($userInfo, "end_date_jd"); //jalali date
$startJD            = getArrayValue($userInfo, "start_date_jd"); //jalali date
$remainingDays      = getArrayValue($userInfo, "remaining_days", 0);
$netmodQrUrl        = getArrayValue($userInfo, "netmod_qr_url", "");
$status             = getArrayValue($userInfo, "status", "");
$arrayConfig        = getArrayValue($userInfo, "array_config", []);
$diffrenceDate      = getArrayValue($userInfo, "diffrence_date", "");
$sshPort            = getArrayValue($arrayConfig, "ssh_port", "");
$udpPort            = getArrayValue($arrayConfig, "udp_port", "");
$host               = getArrayValue($arrayConfig, "host", "");

$remainingText = "";
if ($remainingDays >= 0) {
    $remainingText = "$remainingDays روز";
} else if ($remainingDays < 0) {
    $remainingText = "<span class='text-danger'>" . abs($remainingDays) . " روز گذشته</span>";
}





$sousername = "SoVPN-" . ucfirst($username);


$sohost  = '';
if ($operator == 'HamrahAval'){
	$sohost = 'mci.sovpn.sbs';
} elseif ($operator == 'Irancell') {
	$sohost = 'mtn.sovpn.sbs';
} 

$mobileiphone  = '';
$mobileandroid = '';
if ($mobilebrand == 'iPhone'){
	$mobileiphone   = ' style="display:block!important"';
	$mobileandroid  = ' style="display:none!important"';
} elseif ($mobilebrand == 'Android') {
	$mobileandroid = ' style="display:block!important"';
	$mobileiphone  = ' style="display:none!important"';
} 




$values = [
    [
        "label" => "ترافیک مصرفی",
        "value" => $consumerTraffic ? "<span id='spn-user-traffic'>$consumerTraffic</span>" : 0
    ],
    [
        "label" => "زمان باقی مانده",
        "value" => $remainingText,
    ],
    [
        "label" => "تعداد کاربران",
        "value" => $concurrentUsers,
    ],
	[
        "label" => "مدل گوشی",
        "value" => $mobilebrand,
    ],
	[
        "label" => "سیمکارت",
        "value" => $operator,
    ],
];

?>

<div class="row justify-content-center">
    <div class="col-lg-7">
        <div class="card shadow-lg border-0">
            <div class="card-header border-bottom-0 py-3" rtl>
				<img class="mb-4 sologo" src="<?= baseUrl("assets/images/logo.png") ?>" width="72">
				اطلاعات پروفایل
				<a class="btn btn-danger mt-2 d-block so-exit" href="<?= baseUrl("") ?>">خروج</a>
			</div>
			<div class="card-body">
                <?php if (!empty($settings["logo_url"])) { ?>
                    <div class="text-center">
                        <img src="<?= $settings["logo_url"] ?>" width="100" />
                    </div>
                <?php } ?>
                <?php if (!empty($settings["welecom_text"])) { ?>
                    <div class="text-center border-bottom py-2"><?= $settings["welecom_text"] ?></div>
                <?php } ?>
                <div class="row">
                    <div class="col-lg-8 border-end">
						<?php $class = "d-flex flex-row align-items-center justify-content-between py-2 px-3"; ?>
							<div class="<?= $class ?> border-bottom">
                                <span class="text-muted small">Ssh</span>
								<span class=" fw-bold"><p class="so-widt fw-bold" id="matna3"><?= $sousername ?></p><i class="far fa-copy btn-copy-config btn-float-icon btn-copy-config" onclick="copyToClipboard('#matna3')"></i></span>
							</div>
							<div class="<?= $class ?> border-bottom">
                                <span class="text-muted small">SSH Host</span>
								<span class=" fw-bold"><p class="so-widt fw-bold" id="matna4"><?= $sohost ?></p><i class="far fa-copy btn-copy-config btn-float-icon btn-copy-config" onclick="copyToClipboard('#matna4')"></i></span>
							</div>
							<div class="<?= $class ?> border-bottom">
                                <span class="text-muted small">SSH Port</span>
								<span class=" fw-bold"><p class="so-widt fw-bold" id="matna5"><?= $sshPort ?></p><i class="far fa-copy btn-copy-config btn-float-icon btn-copy-config" onclick="copyToClipboard('#matna5')"></i></span>
							</div>
							<div class="<?= $class ?> border-bottom">
                                <span class="text-muted small">UDP Port</span>
								<span class=" fw-bold"><p class="so-widt fw-bold" id="matna6"><?= $udpPort ?></p><i class="far fa-copy btn-copy-config btn-float-icon btn-copy-config" onclick="copyToClipboard('#matna6')"></i></span>
							</div>
							<div class="<?= $class ?> border-bottom">
                                <span class="text-muted small">SSH Username</span>
								<span class=" fw-bold"><p class="so-widt fw-bold" id="matna7"><?= $username ?></p><i class="far fa-copy btn-copy-config btn-float-icon btn-copy-config" onclick="copyToClipboard('#matna7')"></i></span>
							</div>
							<div class="<?= $class ?> border-bottom">
                                <span class="text-muted small">SSH Password</span>
								<span class=" fw-bold"><p class="so-widt fw-bold" id="matna8"><?= $password ?></p><i class="far fa-copy btn-copy-config btn-float-icon btn-copy-config" onclick="copyToClipboard('#matna8')"></i></span>
							</div>
							
						<?php

                        foreach ($values as  $key => $item) {
                            $label = $item["label"];
                            $value = $item["value"];
                            $class = "d-flex flex-row align-items-center justify-content-between py-2 px-3 border-bottom";
                        ?>
                            <div class="<?= $class ?> border-bottom">
                                <span class="text-muted small"><?= $label ?></span>
                                <span class=" fw-bold"><?= $value ? $value : "-" ?></span>
                            </div>
                        <?php
                        }
                        ?>
						<div class="d-flex flex-row align-items-center justify-content-between py-2 px-3 so-topboarder so-bt">
							<div class="so-align mohidde" <?= $mobileiphone ?>>
								<span class="text-muted fw-bold so-info so-widt so-topboarder">دانلود برنامه ها</span>
								<div class="so-softiconbox">
									<a target="_blank" class="so-softicons" href="<?= baseUrl("https://apps.apple.com/gb/app/npv-tunnel/id1629465476") ?>"><img class="mb-4 so-img" src="<?= baseUrl("assets/images/NapsternetV.png") ?>" width="72"><span class="text-muted so-info so-widt so-softicontitle">NapsternetV</span></a>
									<a target="_blank" class="so-softicons" href="https://apps.apple.com/us/app/streisand/id6450534064"><img class="mb-4 so-img" src="<?= baseUrl("assets/images/Streisand.png") ?>" width='72'><span class="text-muted so-info so-widt so-softicontitle">Streisand</span></a>
								</div>
								<span class="text-muted fw-bold so-info so-widt so-topboarder">راهنمای تنظیم اکانتها در آیفون</span>
								<div class="so-align-img">
									<div class="so-sovideos">
										<video controls poster="<?= baseUrl("assets/images/VideoNapsternetVPooster.png") ?>" controlsList="nodownload">
											<source src="<?= baseUrl("assets/videos/1.mp4") ?>" type="video/mp4">
										</video>
									</div>
									<div class="so-sovideos">
										<video controls poster="<?= baseUrl("assets/images/VideoStreisandPooster.png") ?>" controlsList="nodownload">
											<source src="<?= baseUrl("assets/videos/Streisand in IOS.mp4") ?>" type="video/mp4">
										</video>
									</div>
								</div>
							</div>
							<div class="so-align mohidde" <?= $mobileandroid ?>>
								<span class="text-muted fw-bold so-info so-widt so-topboarder">راهنمای تنظیم اکانتها در اندروید</span>
								<div class="so-align-img">
									<div class="so-sovideos">
										<a target="_blank" class="so-softicons" href="<?= baseUrl("assets/images/HiddifyNG_armeabi-v7a.apk") ?>"><img class="mb-4 so-img" src="<?= baseUrl("assets/images/HiddifyNG.png") ?>" width="72"></a>
										<video controls poster="" controlsList="nodownload">
											<source src="<?= baseUrl("assets/videos/1.mp4") ?>" type="video/mp4">
										</video>
									</div>
									<div class="so-sovideos">
										<a target="_blank" class="so-softicons" href="https://apps.apple.com/us/app/streisand/id6450534064"><img class="mb-4 so-img" src="<?= baseUrl("assets/images/Streisand.png") ?>" width="72"></a>
										<video controls poster="<?= baseUrl("assets/images/VideoiPhonePooster.png") ?>" controlsList="nodownload">
											<source src="<?= baseUrl("assets/videos/Streisand in IOS.mp4") ?>" type="video/mp4">
										</video>
									</div>
								</div>
							</div>
							<div class="so-iconsbox">
								<div class="so-btns"><?=
							
									$lines = '';
									$xuiFile = file_get_contents(baseUrl("views/x-ui.txt"));
									if(strpos($xuiFile, $username) !== false){
										$lines = explode(PHP_EOL, $xuiFile);
										foreach($lines as $line) {
											if (strpos($line, $username) !== false) {
												$findsubs = $line;
											}
										}
									}
									
									function RemoveSpecialChar($findsubs) {
										$res = str_replace( array('"',',',';',':',' ','subId'),'', $findsubs);
										return $res;
									}
									$findsub = RemoveSpecialChar($findsubs); ?>
								
									<button class="btn btn-primary w-100 py-2 so-btn-st" onclick="copyToClipboard('#matna1')">لینک v2Ray<p class="so-widt" id="matna1">https://panel.sovpn.sbs:2087/sub/<?= $findsub ?></p></button>
									<button class="btn btn-primary w-100 py-2 so-btn-st" onclick="copyToClipboard('#matna2')">لینک SSH<p class="so-widt" id="matna2">ssh://<?= $username ?>:<?= $password ?>@<?= $host ?>:<?= $sshPort ?>#SoVPN-<?= ucfirst($username); ?></p></button>	
								</div>
								<div class="so-btns">
									<div class="soPanelCodes" style="display:none!important">
								
										<?=
									
											$stringfiles = json_decode(file_get_contents(baseUrl("views/config.txt")), true);
											$soid1     = array_slice($stringfiles, 3);
											$soid2     = current($soid1);
											$soid3     = array_slice($soid2, 1);
											$soid4     = current($soid3);
											$soid5     = array_slice($soid4, 3);
											$soid6     = current($soid5);
											$soid7     = array_slice($soid6, 0);
											$soid8     = current($soid7);
											$soid9     = array_slice($soid8, 0);
											$soid10    = current($soid9);
											$soid11    = array_slice($soid10, 0);
									
											function array_change_value_case($input, $ucase){
												$case = $ucase;
												$narray = array();
												if (!is_array($input)){
													return $narray;
												}
												foreach ($input as $key => $value){
													if (is_array($value)){
														$narray[$key] = array_change_value_case($value, $case);
														continue;
													}
													$narray[$key] = ($case == CASE_UPPER ? strtoupper($value) : strtolower($value));
												}
												return $narray;
											}
											$jsonfile = array_change_value_case($soid8,CASE_LOWER);
								
											$userdbfile = $jsonfile;
											function searchArrayKeyVal($sKey, $id, $array) {
												foreach ($array as $key => $val) {
													if ($val[$sKey] == $id) {
														return $key;
													}
												}
												return false;
											}
					
											$arrayKey = searchArrayKeyVal("email", $username, $userdbfile);
											if ($arrayKey !== false){
												$fi = $userdbfile[$arrayKey]['id'];
											}
											$uuidFinal = json_encode($fi);
											function RemoveSpecialCharID($uuidFinal) {
												$resuuid = str_replace( array('"','string(36)',' ','"1'),'', $uuidFinal);
												return $resuuid;
											}
											$userUUID = RemoveSpecialCharID($uuidFinal); 
										?>
									</div>
									
									<button class="btn btn-primary w-100 py-2 so-btn-st so-btn-st-vray" style="padding:8px 4px 2px 4px!important;font-size:13px;max-width:100px!important" onclick="copyToClipboard('#matna10')">HamrahAval<p class="so-widt so-widt-vray" id="matna10" style="font-size:0!important;width:100px!important;">vless://<?= $userUUID ?>@xmci.sovpn.sbs:443?type=grpc&serviceName=%40SoVPN&security=tls&fp=chrome&alpn=h2%2Chttp%2F1.1&sni=sbs.sovpn.sbs#SoVPN-<?= ucfirst($username); ?>  HamrahAval</p></button>
									<button class="btn btn-primary w-100 py-2 so-btn-st so-btn-st-vray" style="padding:8px 4px 2px 4px!important;font-size:13px;max-width:100px!important" onclick="copyToClipboard('#matna11')">Irancell<p class="so-widt so-widt-vray" id="matna11" style="font-size:0!important;width:100px!important;">vless://<?= $userUUID ?>@xmtn.sovpn.sbs:443?type=grpc&serviceName=%40SoVPN&security=tls&fp=chrome&alpn=h2%2Chttp%2F1.1&sni=sbs.sovpn.sbs#SoVPN-<?= ucfirst($username); ?>  Irancell</p></button>
									<button class="btn btn-primary w-100 py-2 so-btn-st so-btn-st-vray" style="padding:8px 4px 2px 4px!important;font-size:13px;max-width:100px!important" onclick="copyToClipboard('#matna12')">Mokhaberat<p class="so-widt so-widt-vray" id="matna12" style="font-size:0!important;width:100px!important;">vless://<?= $userUUID ?>@xmkh.sovpn.sbs:443?type=grpc&serviceName=%40SoVPN&security=tls&fp=chrome&alpn=h2%2Chttp%2F1.1&sni=sbs.sovpn.sbs#SoVPN-<?= ucfirst($username); ?>  Mokhaberat</p></button>
									<button class="btn btn-primary w-100 py-2 so-btn-st so-btn-st-vray" style="padding:8px 4px 2px 4px!important;font-size:13px;max-width:100px!important" onclick="copyToClipboard('#matna13')">RighTel<p class="so-widt so-widt-vray" id="matna13" style="font-size:0!important;width:100px!important;">vless://<?= $userUUID ?>@xrtl.sovpn.sbs:443?type=grpc&serviceName=%40SoVPN&security=tls&fp=chrome&alpn=h2%2Chttp%2F1.1&sni=sbs.sovpn.sbs#SoVPN-<?= ucfirst($username); ?>  RighTel</p></button>
									<button class="btn btn-primary w-100 py-2 so-btn-st so-btn-st-vray" style="padding:8px 4px 2px 4px!important;font-size:13px;max-width:100px!important" onclick="copyToClipboard('#matna14')">Shatel<p class="so-widt so-widt-vray" id="matna14" style="font-size:0!important;width:100px!important;">vless://<?= $userUUID ?>@xsht.sovpn.sbs:443?type=grpc&serviceName=%40SoVPN&security=tls&fp=chrome&alpn=h2%2Chttp%2F1.1&sni=sbs.sovpn.sbs#SoVPN-<?= ucfirst($username); ?>  Shatel</p></button>
									<button class="btn btn-primary w-100 py-2 so-btn-st so-btn-st-vray" style="padding:8px 4px 2px 4px!important;font-size:13px;max-width:100px!important" onclick="copyToClipboard('#matna15')">ParsOnlin<p class="so-widt so-widt-vray" id="matna15" style="font-size:0!important;width:100px!important;">vless://<?= $userUUID ?>@xprs.sovpn.sbs:443?type=grpc&serviceName=%40SoVPN&security=tls&fp=chrome&alpn=h2%2Chttp%2F1.1&sni=sbs.sovpn.sbs#SoVPN-<?= ucfirst($username); ?>  ParsOnlin</p></button>
									<button class="btn btn-primary w-100 py-2 so-btn-st so-btn-st-vray" style="padding:8px 4px 2px 4px!important;font-size:13px;max-width:100px!important" onclick="copyToClipboard('#matna16')">AsiaTek<p class="so-widt so-widt-vray" id="matna16" style="font-size:0!important;width:100px!important;">vless://<?= $userUUID ?>@xast.sovpn.sbs:443?type=grpc&serviceName=%40SoVPN&security=tls&fp=chrome&alpn=h2%2Chttp%2F1.1&sni=sbs.sovpn.sbs#SoVPN-<?= ucfirst($username); ?>  AsiaTek</p></button>
									<button class="btn btn-primary w-100 py-2 so-btn-st so-btn-st-vray" style="padding:8px 4px 2px 4px!important;font-size:13px;max-width:100px!important" onclick="copyToClipboard('#matna17')">MobinNet<p class="so-widt so-widt-vray" id="matna17" style="font-size:0!important;width:100px!important;">vless://<?= $userUUID ?>@xmbt.sovpn.sbs:443?type=grpc&serviceName=%40SoVPN&security=tls&fp=chrome&alpn=h2%2Chttp%2F1.1&sni=sbs.sovpn.sbs#SoVPN-<?= ucfirst($username); ?>  MobinNet</p></button>
									<button class="btn btn-primary w-100 py-2 so-btn-st so-btn-st-vray" style="padding:8px 4px 2px 4px!important;font-size:13px;max-width:100px!important" onclick="copyToClipboard('#matna18')">AndisheSabz<p class="so-widt so-widt-vray" id="matna18" style="font-size:0!important;width:100px!important;">vless://<?= $userUUID ?>@xask.sovpn.sbs:443?type=grpc&serviceName=%40SoVPN&security=tls&fp=chrome&alpn=h2%2Chttp%2F1.1&sni=sbs.sovpn.sbs#SoVPN-<?= ucfirst($username); ?>  AndisheSabz</p></button>
									<button class="btn btn-primary w-100 py-2 so-btn-st so-btn-st-vray" style="padding:8px 4px 2px 4px!important;font-size:13px;max-width:100px!important" onclick="copyToClipboard('#matna19')">PishGaman<p class="so-widt so-widt-vray" id="matna19" style="font-size:0!important;width:100px!important;">vless://<?= $userUUID ?>@xpsm.sovpn.sbs:443?type=grpc&serviceName=%40SoVPN&security=tls&fp=chrome&alpn=h2%2Chttp%2F1.1&sni=sbs.sovpn.sbs#SoVPN-<?= ucfirst($username); ?>  PishGaman</p></button>
									<button class="btn btn-primary w-100 py-2 so-btn-st so-btn-st-vray" style="padding:8px 4px 2px 4px!important;font-size:13px;max-width:100px!important" onclick="copyToClipboard('#matna20')">SabaNet<p class="so-widt so-widt-vray" id="matna20" style="font-size:0!important;width:100px!important;">vless://<?= $userUUID ?>@xsbn.sovpn.sbs:443?type=grpc&serviceName=%40SoVPN&security=tls&fp=chrome&alpn=h2%2Chttp%2F1.1&sni=sbs.sovpn.sbs#SoVPN-<?= ucfirst($username); ?>  SabaNet</p></button>
								</div>	
								<div class="so-textBoxpanel">
									<span class="text-muted fw-bold so-info so-widt so-topboarder so-textBoxTitr">اخبار</span>
									<div class="so-textBox">
										...
									</div>
								</div>
							</div>
						</div>
					</div>
                </div>
            </div>
        </div>
    </div>
</div>