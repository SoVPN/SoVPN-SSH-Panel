<?php
$userId             = getArrayValue($userInfo, "id");
$username           = getArrayValue($userInfo, "username");
$password           = getArrayValue($userInfo, "password");
$email              = getArrayValue($userInfo, "email");
$mobile             = getArrayValue($userInfo, "mobile");
$traffic            = getArrayValue($userInfo, "format_traffic");
$startDate          = getArrayValue($userInfo, "start_date");
$endDate            = getArrayValue($userInfo, "end_date");
$expiryDays         = getArrayValue($userInfo, "expiry_days");
$expiryType         = getArrayValue($userInfo, "expiry_type");
$mobilebrand        = getArrayValue($userInfo, "mobilebrand");
$operator           = getArrayValue($userInfo, "operator");
$desc               = getArrayValue($userInfo, "desc");
$concurrentUsers    = getArrayValue($userInfo, "limit_users");
$consumerTraffic    = getArrayValue($userInfo, "format_consumer_traffic");
$endDateJD          = getArrayValue($userInfo, "end_date_jd"); //jalali date
$startJD            = getArrayValue($userInfo, "start_date_jd"); //jalali date
$remainingDays      = getArrayValue($userInfo, "remaining_days", 0);
$netmodQrUrl        = getArrayValue($userInfo, "netmod_qr_url", "");
$status             = getArrayValue($userInfo, "status", "");
$arrayConfig        = getArrayValue($userInfo, "array_config", []);
$diffrenceDate      = getArrayValue($userInfo, "diffrence_date", "");
$sshPort            = getArrayValue($arrayConfig, "ssh_port", "");
$udpPort            = getArrayValue($arrayConfig, "udp_port", "");
$host               = getArrayValue($arrayConfig, "host", "");

$remainingText = "";
if ($remainingDays >= 0) {
    $remainingText = "$remainingDays روز";
} else if ($remainingDays < 0) {
    $remainingText = "<span class='text-danger'>" . abs($remainingDays) . " روز گذشته</span>";
}

$sousername = "SoVPN-" . ucfirst($username);

$values = [
	[
        "label" => "Ssh",
        "value" => $sousername,
    ],
    [
        "label" => "SSH Host",
        "value" => "mci.sovpn.sbs",
    ],
    [
        "label" => "SSH Port",
        "value" => $sshPort,
    ],
    [
        "label" => "UDP Port",
        "value" => $udpPort,
    ],
	[
        "label" => "SSH Username",
        "value" => $username,
    ],
    [
        "label" => "SSH Password",
        "value" => $password,
    ],
    [
        "label" => "ترافیک مصرفی",
        "value" => $consumerTraffic ? "<span id='spn-user-traffic'>$consumerTraffic</span>" : 0
    ],
    [
        "label" => "زمان باقی مانده",
        "value" => $remainingText,
    ],
    [
        "label" => "تعداد کاربران",
        "value" => $concurrentUsers,
    ],
	[
        "label" => "مدل گوشی",
        "value" => $mobilebrand,
    ],
	[
        "label" => "سیمکارت",
        "value" => $operator,
    ],
];

?>

<div class="row justify-content-center">
    <div class="col-lg-7">
        <div class="card shadow-lg border-0">
            <div class="card-header border-bottom-0 py-3" rtl>
				<img class="mb-4 sologo" src="<?= baseUrl("assets/images/logo.png") ?>" width="72">
				اطلاعات پروفایل
				<a class="btn btn-danger mt-2 d-block so-exit" href="<?= baseUrl("") ?>">خروج</a>
			</div>
			<div class="card-body">
                <?php if (!empty($settings["logo_url"])) { ?>
                    <div class="text-center">
                        <img src="<?= $settings["logo_url"] ?>" width="100" />
                    </div>
                <?php } ?>
                <?php if (!empty($settings["welecom_text"])) { ?>
                    <div class="text-center border-bottom py-2"><?= $settings["welecom_text"] ?></div>
                <?php } ?>
                <div class="row">
                    <div class="col-lg-8 border-end">
                        <?php
                        foreach ($values as  $key => $item) {
                            $label = $item["label"];
                            $value = $item["value"];
                            $class = "d-flex flex-row align-items-center justify-content-between py-2 px-3";
                            if ($key < count($values) - 1) {
                                $class .= " border-bottom";
                            }
                        ?>
                            <div class="<?= $class ?>">
                                <span class="text-muted small"><?= $label ?></span>
                                <span class=" fw-bold"><?= $value ? $value : "-" ?></span>
                            </div>
                        <?php
                        }
                        ?>
						<div class="<?= $class ?> so-topboarder so-bt">
							<div class="so-align">
								<span class="text-muted fw-bold so-info so-widt so-topboarder">راهنمای تنظیم اکانتها در آیفون</span>
								<div class="so-align-img">
									<div class="so-softicon">
										<a target="_blank" class="so-softicon" href="<?= baseUrl("https://apps.apple.com/gb/app/npv-tunnel/id1629465476") ?>"><img class="mb-4 so-img" src="<?= baseUrl("assets/images/NapsternetV.png") ?>" width="72"></a>
										<video controls poster="<?= baseUrl("assets/images/VideoNapsternetVPooster.png") ?>" controlsList="nodownload">
											<source src="<?= baseUrl("assets/videos/1.mp4") ?>" type="video/mp4">
										</video>
									</div>
									<div class="so-softicon">
										<a target="_blank" class="so-softicon" href="https://apps.apple.com/us/app/streisand/id6450534064"><img class="mb-4 so-img" src="<?= baseUrl("assets/images/Streisand.png") ?>" width="72"></a>
										<video controls poster="<?= baseUrl("assets/images/VideoStreisandPooster.png") ?>" controlsList="nodownload">
											<source src="<?= baseUrl("assets/videos/Streisand in IOS.mp4") ?>" type="video/mp4">
										</video>
									</div>
								</div>
							</div>
							<div class="so-align">
								<span class="text-muted fw-bold so-info so-widt so-topboarder">راهنمای تنظیم اکانتها در اندروید</span>
								<div class="so-align-img">
									<div class="so-softicon">
										<a target="_blank" class="so-softicon" href="<?= baseUrl("assets/images/HiddifyNG_armeabi-v7a.apk") ?>"><img class="mb-4 so-img" src="<?= baseUrl("assets/images/HiddifyNG.png") ?>" width="72"></a>
										<video controls poster="" controlsList="nodownload">
											<source src="<?= baseUrl("assets/videos/1.mp4") ?>" type="video/mp4">
										</video>
									</div>
									<div class="so-softicon">
										<a target="_blank" class="so-softicon" href="https://apps.apple.com/us/app/streisand/id6450534064"><img class="mb-4 so-img" src="<?= baseUrl("assets/images/Streisand.png") ?>" width="72"></a>
										<video controls poster="<?= baseUrl("assets/images/VideoiPhonePooster.png") ?>" controlsList="nodownload">
											<source src="<?= baseUrl("assets/videos/Streisand in IOS.mp4") ?>" type="video/mp4">
										</video>
									</div>
								</div>
							</div>
							<div class="so-iconsbox">
								<div class="so-btns"><?php
									$sophoneand = "Android";
									$sophoneios = "iPhone";
									$sosimirancell = "Irancell";
									$sosimhamrah = "HamrahAval";
									$roadName = $username;
									$file = file_get_contents(baseUrl("views/x-ui.db"));
									if(strpos($file,$roadName) !== false){
										$lines = explode(PHP_EOL,$file);
										foreach($lines as $line) {
											if (strpos($line,$roadName) !== false) {
												$str = $line;
											}
										}
									}
									function RemoveSpecialChar($str) {
										$res = str_replace( array('"',',',';',':',' ','subId'),'', $str);
											return $res;
										}
										$str1 = RemoveSpecialChar($str);
									?>
									<button class="btn btn-primary w-100 py-2 so-btn-st" onclick="copyToClipboard('#matna1')">لینک v2Ray<p class="so-widt" id="matna1">https://panel.sovpn.sbs:2087/sub/<?= $str1 ?></p></button>
									<button class="btn btn-primary w-100 py-2 so-btn-st" onclick="copyToClipboard('#matna2')">لینک SSH<p class="so-widt" id="matna2">ssh://<?= $username ?>:<?= $password ?>@<?= $host ?>:<?= $sshPort ?>#SoVPN-<?= ucfirst($username); ?></p></button>	
								</div>
								<div class="so-textBoxpanel">
									<span class="text-muted fw-bold so-info so-widt so-topboarder so-textBoxTitr">اخبار</span>
									<div class="so-textBox">
										...
									</div>
								</div>
							</div>
						</div>
					</div>
                </div>
            </div>
        </div>
    </div>
</div>