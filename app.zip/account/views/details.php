<?php
$userId             = getArrayValue($userInfo, "id");
$username           = getArrayValue($userInfo, "username");
$password           = getArrayValue($userInfo, "password");
$email              = getArrayValue($userInfo, "email");
$mobile             = getArrayValue($userInfo, "mobile");
$traffic            = getArrayValue($userInfo, "format_traffic");
$startDate          = getArrayValue($userInfo, "start_date");
$endDate            = getArrayValue($userInfo, "end_date");
$expiryDays         = getArrayValue($userInfo, "expiry_days");
$expiryType         = getArrayValue($userInfo, "expiry_type");
$mobilebrand        = getArrayValue($userInfo, "mobilebrand");
$operator           = getArrayValue($userInfo, "operator");
$useruuid           = getArrayValue($userInfo, "useruuid");
$usersubs           = getArrayValue($userInfo, "usersubs");
$usersinfo          = getArrayValue($userInfo, "usersinfo");
$desc               = getArrayValue($userInfo, "desc");
$concurrentUsers    = getArrayValue($userInfo, "limit_users");
$consumerTraffic    = getArrayValue($userInfo, "format_consumer_traffic");
$endDateJD          = getArrayValue($userInfo, "end_date_jd"); //jalali date
$startJD            = getArrayValue($userInfo, "start_date_jd"); //jalali date
$remainingDays      = getArrayValue($userInfo, "remaining_days", 0);
$netmodQrUrl        = getArrayValue($userInfo, "netmod_qr_url", "");
$status             = getArrayValue($userInfo, "status", "");
$arrayConfig        = getArrayValue($userInfo, "array_config", []);
$diffrenceDate      = getArrayValue($userInfo, "diffrence_date", "");
$sshPort            = getArrayValue($arrayConfig, "ssh_port", "");
$udpPort            = getArrayValue($arrayConfig, "udp_port", "");
$host               = getArrayValue($arrayConfig, "host", "");

$remainingText = "";
if ($remainingDays >= 0) {
    $remainingText = "$remainingDays روز";
} else if ($remainingDays < 0) {
    $remainingText = "<span class='text-danger'>" . abs($remainingDays) . " روز گذشته</span>";
}





$sousername = "SoVPN-" . ucfirst($username);


$sohost  = '';
if ($operator == 'HamrahAval'){
	$sohost = 'mci.sovpn.sbs';
} elseif ($operator == 'Irancell') {
	$sohost = 'mtn.sovpn.sbs';
} 

$mobileiphone  = '';
$mobileandroid = '';
if ($mobilebrand == 'iPhone'){
	$mobileiphone   = ' style="display:block!important"';
	$mobileandroid  = ' style="display:none!important"';
} elseif ($mobilebrand == 'Android') {
	$mobileandroid = ' style="display:block!important"';
	$mobileiphone  = ' style="display:none!important"';
} 




$values = [
    [
        "label" => "ترافیک مصرفی",
        "value" => $consumerTraffic ? "<span id='spn-user-traffic'>$consumerTraffic</span>" : 0
    ],
    [
        "label" => "زمان باقی مانده",
        "value" => $remainingText,
    ],
    [
        "label" => "تعداد کاربران",
        "value" => $concurrentUsers,
    ],
	[
        "label" => "مدل گوشی",
        "value" => $mobilebrand,
    ],
	[
        "label" => "سیمکارت",
        "value" => $operator,
    ],
];

?>

<div class="row-aco justify-content-center">
    <div class="col-lg-7">
        <div class="card shadow-lg border-0">
            <div class="card-header border-bottom-0 py-3" rtl>
				<img class="mb-4 sologo" src="<?= baseUrl("assets/images/logo.png") ?>" width="72">
				اطلاعات پروفایل
				<a class="btn btn-danger mt-2 d-block btnExit" href="<?= baseUrl("") ?>">خروج</a>
			</div>
			<div class="card-body">
                <?php if (!empty($settings["logo_url"])) { ?>
                    <div class="text-center">
                        <img src="<?= $settings["logo_url"] ?>" width="100" />
                    </div>
                <?php } ?>
                <?php if (!empty($settings["welecom_text"])) { ?>
                    <div class="text-center border-bottom py-2"><?= $settings["welecom_text"] ?></div>
                <?php } ?>
                <div class="row-acount">
                    <div class="col-lg-8 border-end">
						<?php $class = "d-flex flex-row align-items-center justify-content-between"; ?>
							<div class="<?= $class ?> border-bottom">
                                <span class="text-muted small">Ssh</span>
								<span id="matna3" class="fw-bold btnClon" onclick="copyToClipboard('#matna3')" title="کپی"><?= $sousername ?><i class="far fa-copy btn-copy-config btn-float-icon"></i></span>
							</div>
							<div class="<?= $class ?> border-bottom">
                                <span class="text-muted small">SSH Host</span>
								<span id="matna4" class="fw-bold btnClon" onclick="copyToClipboard('#matna4')" title="کپی"><?= $sohost ?><i class="far fa-copy btn-copy-config btn-float-icon"></i></span>
							</div>
							<div class="<?= $class ?> border-bottom">
                                <span class="text-muted small">SSH Port</span>
								<span id="matna5" class="fw-bold btnClon" onclick="copyToClipboard('#matna5')" title="کپی"><?= $sshPort ?><i class="far fa-copy btn-copy-config btn-float-icon"></i></span>
							</div>
							<div class="<?= $class ?> border-bottom">
                                <span class="text-muted small">UDP Port</span>
								<span id="matna6" class="fw-bold btnClon" onclick="copyToClipboard('#matna6')" title="کپی"><?= $udpPort ?><i class="far fa-copy btn-copy-config btn-float-icon"></i></span>
							</div>
							<div class="<?= $class ?> border-bottom">
                                <span class="text-muted small">SSH Username</span>
								<span id="matna7" class="fw-bold btnClon" onclick="copyToClipboard('#matna7')" title="کپی"><?= $username ?><i class="far fa-copy btn-copy-config btn-float-icon"></i></span>
							</div>
							<div class="<?= $class ?> border-bottom">
                                <span class="text-muted small">SSH Password</span>
								<span id="matna8" class="fw-bold btnClon" onclick="copyToClipboard('#matna8')" title="کپی"><?= $password ?><i class="far fa-copy btn-copy-config btn-float-icon"></i></span>
							</div>
							
						<?php

                        foreach ($values as  $key => $item) {
                            $label = $item["label"];
                            $value = $item["value"];
                            $class = "d-flex flex-row align-items-center justify-content-between border-bottom height-line";
                        ?>
                            <div class="<?= $class ?> border-bottom">
                                <span class="text-muted small"><?= $label ?></span>
                                <span class=" fw-bold"><?= $value ? $value : "-" ?></span>
                            </div>
                        <?php
                        }
                        ?>
						<div class="d-flex flex-row align-items-center justify-content-between so-topboarder so-bt">
							<div class="so-align mohidde" <?= $mobileiphone ?>>
								<span class="text-muted fw-bold so-info so-widt so-topboarder">دانلود برنامه ها</span>
								<div class="so-softiconbox">
									<a target="_blank" class="so-softicons" href="<?= baseUrl("https://apps.apple.com/gb/app/npv-tunnel/id1629465476") ?>"><img class="mb-4 so-img" src="<?= baseUrl("assets/images/NapsternetV.png") ?>" width="72"><span class="text-muted so-info so-widt so-softicontitle">NapsternetV</span></a>
									<a target="_blank" class="so-softicons" href="https://apps.apple.com/us/app/streisand/id6450534064"><img class="mb-4 so-img" src="<?= baseUrl("assets/images/Streisand.png") ?>" width='72'><span class="text-muted so-info so-widt so-softicontitle">Streisand</span></a>
								</div>
								<span class="text-muted fw-bold so-info so-widt so-topboarder">راهنمای تنظیم اکانتها در آیفون</span>
								<div class="so-align-img">
									<!--div class="so-sovideos">
										<video controls poster="<!--?= baseUrl("assets/images/VideoNapsternetVPooster.png") ?>" controlsList="nodownload">
											<source src="<!--?= baseUrl("assets/videos/1.mp4") ?>" type="video/mp4">
										</video>
									</div-->
									<div class="so-sovideos">
										<video controls poster="<?= baseUrl("assets/images/VideoStreisandPooster.png") ?>" controlsList="nodownload">
											<source src="<?= baseUrl("assets/videos/Streisand in IOS.mp4") ?>" type="video/mp4">
										</video>
									</div>
								</div>
							</div>
							<div class="so-align mohidde" <?= $mobileandroid ?>>
								<span class="text-muted fw-bold so-info so-widt so-topboarder">راهنمای تنظیم اکانتها در اندروید</span>
								<div class="so-align-img">
									<div class="so-sovideos">
										<a target="_blank" class="so-softicons" href="<?= baseUrl("assets/images/HiddifyNG_armeabi-v7a.apk") ?>"><img class="mb-4 so-img" src="<?= baseUrl("assets/images/HiddifyNG.png") ?>" width="72"></a>
										<video controls poster="" controlsList="nodownload">
											<source src="<?= baseUrl("assets/videos/1.mp4") ?>" type="video/mp4">
										</video>
									</div>
									<div class="so-sovideos">
										<a target="_blank" class="so-softicons" href="https://apps.apple.com/us/app/streisand/id6450534064"><img class="mb-4 so-img" src="<?= baseUrl("assets/images/Streisand.png") ?>" width="72"></a>
										<video controls poster="<?= baseUrl("assets/images/VideoiPhonePooster.png") ?>" controlsList="nodownload">
											<source src="<?= baseUrl("assets/videos/Streisand in IOS.mp4") ?>" type="video/mp4">
										</video>
									</div>
								</div>
							</div>
							<div class="so-iconsbox">
								<div class="so-btns so-btns-ssh">
									<button class="btn-vless" onclick="copyToClipboard('#matna1')">لینک v2Ray<p id="matna1">https://panel.sovpn.sbs:2087/sub/<?= $usersubs?></p></button>
									<button class="btn-vless" onclick="copyToClipboard('#matna2')">لینک SSH<p id="matna2">ssh://<?= $username ?>:<?= $password ?>@<?= $host ?>:<?= $sshPort ?>#SoVPN-<?= ucfirst($username); ?></p></button>	
								</div>
								<div class="so-btns so-btns-vray">
									<!--?= print_r($jsonfilee) ?-->
									<!--?= $userUUID ?-->
									<!--?= var_dump($userUUID) ?-->
									<div class="diViderTop">
										<p class="fw-bold">لینک تکی تنظیمات برای هر اپراتور</p>
										<span class="btn-vless" onclick="copyToClipboard('#matna10')" title="کپی">HamrahAval<p id="matna10">vless://<?= $useruuid ?>@xmci.sovpn.sbs:443?type=grpc&serviceName=%40SoVPN&security=tls&fp=chrome&alpn=h2%2Chttp%2F1.1&sni=sbs.sovpn.sbs#SoVPN-<?= ucfirst($username); ?>  HamrahAval</p></span>
										<span class="btn-vless" onclick="copyToClipboard('#matna11')" title="کپی">Irancell<p id="matna11">vless://<?= $useruuid ?>@xmtn.sovpn.sbs:443?type=grpc&serviceName=%40SoVPN&security=tls&fp=chrome&alpn=h2%2Chttp%2F1.1&sni=sbs.sovpn.sbs#SoVPN-<?= ucfirst($username); ?>  Irancell</p></span>
										<button class="btn-vless" onclick="copyToClipboard('#matna12')" title="کپی">Mokhaberat<p id="matna12">vless://<?= $useruuid ?>@xmkh.sovpn.sbs:443?type=grpc&serviceName=%40SoVPN&security=tls&fp=chrome&alpn=h2%2Chttp%2F1.1&sni=sbs.sovpn.sbs#SoVPN-<?= ucfirst($username); ?>  Mokhaberat</p></button>
										<button class="btn-vless" onclick="copyToClipboard('#matna13')" title="کپی">RighTel<p id="matna13">vless://<?= $useruuid ?>@xrtl.sovpn.sbs:443?type=grpc&serviceName=%40SoVPN&security=tls&fp=chrome&alpn=h2%2Chttp%2F1.1&sni=sbs.sovpn.sbs#SoVPN-<?= ucfirst($username); ?>  RighTel</p></button>
										<button class="btn-vless" onclick="copyToClipboard('#matna14')" title="کپی">Shatel<p id="matna14">vless://<?= $useruuid ?>@xsht.sovpn.sbs:443?type=grpc&serviceName=%40SoVPN&security=tls&fp=chrome&alpn=h2%2Chttp%2F1.1&sni=sbs.sovpn.sbs#SoVPN-<?= ucfirst($username); ?>  Shatel</p></button>
										<button class="btn-vless" onclick="copyToClipboard('#matna15')" title="کپی">ParsOnlin<p id="matna15">vless://<?= $useruuid ?>@xprs.sovpn.sbs:443?type=grpc&serviceName=%40SoVPN&security=tls&fp=chrome&alpn=h2%2Chttp%2F1.1&sni=sbs.sovpn.sbs#SoVPN-<?= ucfirst($username); ?>  ParsOnlin</p></button>
										<button class="btn-vless" onclick="copyToClipboard('#matna16')" title="کپی">AsiaTek<p id="matna16">vless://<?= $useruuid ?>@xast.sovpn.sbs:443?type=grpc&serviceName=%40SoVPN&security=tls&fp=chrome&alpn=h2%2Chttp%2F1.1&sni=sbs.sovpn.sbs#SoVPN-<?= ucfirst($username); ?>  AsiaTek</p></button>
										<button class="btn-vless" onclick="copyToClipboard('#matna17')" title="کپی">MobinNet<p id="matna17">vless://<?= $useruuid ?>@xmbt.sovpn.sbs:443?type=grpc&serviceName=%40SoVPN&security=tls&fp=chrome&alpn=h2%2Chttp%2F1.1&sni=sbs.sovpn.sbs#SoVPN-<?= ucfirst($username); ?>  MobinNet</p></button>
										<button class="btn-vless" onclick="copyToClipboard('#matna18')" title="کپی">AndisheSabz<p id="matna18">vless://<?= $useruuid ?>@xask.sovpn.sbs:443?type=grpc&serviceName=%40SoVPN&security=tls&fp=chrome&alpn=h2%2Chttp%2F1.1&sni=sbs.sovpn.sbs#SoVPN-<?= ucfirst($username); ?>  AndisheSabz</p></button>
										<button class="btn-vless" onclick="copyToClipboard('#matna19')" title="کپی">PishGaman<p id="matna19">vless://<?= $useruuid ?>@xpsm.sovpn.sbs:443?type=grpc&serviceName=%40SoVPN&security=tls&fp=chrome&alpn=h2%2Chttp%2F1.1&sni=sbs.sovpn.sbs#SoVPN-<?= ucfirst($username); ?>  PishGaman</p></button>
										<button class="btn-vless" onclick="copyToClipboard('#matna20')" title="کپی">SabaNet<p id="matna20">vless://<?= $useruuid ?>@xsbn.sovpn.sbs:443?type=grpc&serviceName=%40SoVPN&security=tls&fp=chrome&alpn=h2%2Chttp%2F1.1&sni=sbs.sovpn.sbs#SoVPN-<?= ucfirst($username); ?>  SabaNet</p></button>
									</div>
								</div>	
								<div class="so-textBoxpanel">
									<span class="text-muted fw-bold so-info so-widt so-topboarder so-textBoxTitr">اخبار</span>
									<div class="so-textBox">
										...
									</div>
								</div>
							</div>
						</div>
					</div>
                </div>
            </div>
        </div>
    </div>
</div>